#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors

//Drive Motors
motor leftMotorFront = motor(PORT1, ratio6_1, true);
motor leftMotorMiddle = motor(PORT6, ratio6_1, true);
motor leftMotorBack = motor(PORT10, ratio6_1, true);
motor_group LeftDriveSmart = motor_group(leftMotorFront, leftMotorMiddle, leftMotorBack);
motor rightMotorFront = motor(PORT20, ratio6_1, false);
motor rightMotorMiddle = motor(PORT15, ratio6_1, false);
motor rightMotorBack = motor(PORT11, ratio6_1, false);
motor_group RightDriveSmart = motor_group(rightMotorFront, rightMotorMiddle, rightMotorBack);

inertial angleTracking = inertial(PORT19);

motor arm = motor(PORT5, ratio36_1, false);


motor intake = motor(PORT16, ratio6_1, true);


// smartdrive Drivetrains = smartdrive(LeftDriveSmart, RightDriveSmart, inertial1, 299.24, 276.352, 27.7876, mm, 1);
drivetrain Drivetrains = drivetrain(LeftDriveSmart, RightDriveSmart, 219.44, 349.25, 304.79999999999995, mm, 0.75);
controller Controller1 = controller(primary);

rotation trackingM = rotation(PORT13, false);
rotation trackingR = rotation(PORT14, false);
rotation trackingL = rotation(PORT17, false);

rotation armDeg = rotation(PORT9, true);

digital_out clamp = digital_out(Brain.ThreeWirePort.H);

digital_out doinker = digital_out(Brain.ThreeWirePort.D);

digital_out and_we_and_lift_off = digital_out(Brain.ThreeWirePort.A);





/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  Brain.Screen.print("Device initialization...");
  Brain.Screen.setCursor(2, 1);
  // calibrate the drivetrain Inertial
  wait(200, msec);
  // inertial1.calibrate();
  // // inertial12.calibrate();
  // // inertial13.calibrate();
  // Brain.Screen.print("Calibrating Inertial for Drivetrain");
  // // wait for the Inertial calibration process to finish
  // while (inertial1.isCalibrating()) {
  //   wait(25, msec);
  // }
  // reset the screen now that the calibration is complete
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1,1);
  wait(50, msec);
  Brain.Screen.clearScreen();
}