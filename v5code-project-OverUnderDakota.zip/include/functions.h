#ifndef FUNCTIONS_H
#define FUNCTIONS_H

using namespace vex;
 void DriveRev(double distace, distanceUnits units, double speed, directionType dir);
 void DriveForw(double distace, distanceUnits units, double speed, directionType dir);
 void spinForw(double speed, directionType dir);
 void Balenced();
 void runOnEvent();

 
#endif