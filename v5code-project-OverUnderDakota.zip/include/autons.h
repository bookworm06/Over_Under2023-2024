#ifndef AUTONS_H
#define AUTONS_H

void TestAuton();


void leftSimple();
void rightSimple();
void rightHard();
void winPoint();
void slam();
void killMeNow();

#endif