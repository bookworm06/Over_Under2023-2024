#ifndef FUNCTIONS_H
#define FUNCTIONS_H

using namespace vex;
 void turnToDegree(float ang, rotationUnits units, double speed, double Degree_error_to_Start_to_deaccele, double drivetimer) ;
 void DriveTo(double distace, distanceUnits units, double speed, directionType dir);
 void DriveNoPID(double dist, distanceUnits units, double speed, directionType dir);
 void turnTo(turnType dir, float ang, rotationUnits units, double speed, velocityUnits speedUnits);
//  void spinForw(double speed, directionType dir);
 void spinFlywheel();
 void stopFlywheel();
 void wingsOut();
 void wingsIn();
 void wingLOut();
 void wingLIn();
 void wingROut();
 void wingRIn();
 void slow();
 void speed();
 void armUp();
 void armDown();
 void function(directionType dir, int dist, int speed);
 void runOnEvent();

 
#endif