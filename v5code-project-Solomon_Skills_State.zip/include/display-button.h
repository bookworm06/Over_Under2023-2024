void displayButtonControls( int index, bool pressed );
int findButton(  int16_t xpos, int16_t ypos );
void initButtons();
void userTouchCallbackPressed();
void userTouchCallbackReleased();