#include <string>
#include <cmath>

enum class vectorUnits {

  Rect,
  Polar

};


class vector{

  private:
  double x,y;
  std::string type;

  public:
  vector(double a, double b, std::string A): x(a), y(b), type(A){};
  vector(const vector &k){
    x = k.x;
    y = k.y;
    type = k.type;
  };
  vector(double a, double b): x(a), y(b){
    type = "Rect";
  };
  vector(){
  x = 0;
  y = 0;
  type = "Rect";

  }
  double constrainAngle360(double x){
    x = fmod(x,2*M_PI);
    if (x < 0)
        x += 2*M_PI;
    return x;
  }
};