#include "vex.h" 
#include "functions.h"
#include "cmath"

using namespace vex;

vex:: timer Drivetime;
#include <iostream>

void turnToDegree(float ang, rotationUnits units, double speed, double Degree_error_to_Start_to_deaccele, double drivetimer) {
  // int pos1 = inertial1.rotation();
  // int pos2 = inertial1.rotation();
  // int pos3 = inertial1.rotation();
  int count = 0;
  // int avPos = (pos1 + pos2 + pos3)/3;


  double starttime = Brain.Timer.value() ;
  double orio2 ;
  double BlahBlahBlah ;
  double variable2 ; 
  double asdfghjkl ;
  double Taget_Velocoty = 0; 
  double checktargetvelocity ; 
  
  int programorder ; 
  double Deaccelerationtotal ;



  // Suggest 20 for start to deaccel value
  
  // Drivetrains.setHeading(avPos, rev);
  Drivetrains.setTurnVelocity(speed, percentUnits::pct);
  while(true){ 
    // std::cout<<  avPos<< "," << Taget_Velocoty<< "," <<ang;


    // pos1 = inertial1.rotation();
    // pos2 = inertial1.rotation();
    // pos3 = inertial1.rotation();
    // avPos = (pos1 + pos2 + pos3)/3;
    //
    if( ( starttime + drivetimer ) < Brain.Timer.value() ){
      //Unfinished_alarm = true;
      break;
    }


  //   // if(StopAutonSubprograms==true){
  //   //   break;
    
    
    
    
    
    //  orio2 = avPos;
    //  // gets orio2 within 360 deg.
    // while ( orio2> 360 or orio2<-360){
    //  if(1==0){}
    //  else if (orio2>=360){
    //   orio2=orio2-360;
    //  }
    //  else if (orio2<=-360){
    //   orio2=orio2+360;
    //  }
    // }

    // //reverses heading
    //  BlahBlahBlah = orio2+180;
    // if(1==0){}
    // else if (BlahBlahBlah>=360){
    //  BlahBlahBlah=BlahBlahBlah-360;
    // }
    // else if (BlahBlahBlah<=-360){
    //  BlahBlahBlah=BlahBlahBlah+360;
    // }
    // ///

    // variable2=0;
    // if( 1==1 ){ //travelrev==false // facing the direction fword
    //  variable2=orio2;
    // }
    // // else if ( travelrev==true ){
    // // variable2=BlahBlahBlah;
    // // }
    
    // if(variable2>180){
    // variable2=(180-(variable2 - 180))*-1 ;
    // }
    // else if(variable2<-180){
    // variable2=(180+(variable2 + 180)) ;
    // }
    // //////////////////////////////////

    //  asdfghjkl = ang - variable2;
    //  if(asdfghjkl>180){
    //   asdfghjkl = asdfghjkl-360;
    //  }
    //  else if(asdfghjkl<-180){
    //   asdfghjkl = asdfghjkl+360;
    //  }
    // //////////////////////////////////////////////////
   
    //   if((asdfghjkl<=-Degree_error_to_Start_to_deaccele) or(asdfghjkl>=Degree_error_to_Start_to_deaccele)){
    //     programorder = 1 ; 
    //    Deaccelerationtotal=speed;

    //     Taget_Velocoty = speed ; 

      
    //     }


    //  else if((asdfghjkl>-Degree_error_to_Start_to_deaccele) and (asdfghjkl<Degree_error_to_Start_to_deaccele)){
    //          programorder = 2  ; 
    //          Taget_Velocoty  = (speed /  Degree_error_to_Start_to_deaccele   ) * asdfghjkl ; 
    //          checktargetvelocity  =(speed /  Degree_error_to_Start_to_deaccele   ) * asdfghjkl ; 
    //          if (Taget_Velocoty > speed){
    //            Taget_Velocoty = speed ; 
    //          }
    //          else if (Taget_Velocoty <  - speed){
    //            Taget_Velocoty = -speed ; 
    //          }
               
           
        
          
    //   }













    count += 1;
    // std::cout<<  avPos<< "," << Taget_Velocoty<< "," <<ang;
    if(ang - 0.08 <=  ang + 0.08 >= ang){
      break;
    }else if ( count == 1){

      Drivetrains.turnFor(ang, units, speed, velocityUnits(pct));
    }
  }
  Drivetrains.stop(hold);
  wait(20, msec);
}

void DriveTo(double dist, distanceUnits units, double speed, directionType dir) {
  // int stopCount = 0;
  // double thresh = 0.5;
  // int settleTime = 5;
  int driveTime = 0;

  tracking1.resetRotation();
  // RightDriveSmart.resetPosition();
  float distance_trav = 0.0;

  double kp = 1.12;
  double ki;
  double kd = 1;

  double prev_error = 0;

  while(true) {

    float left_distance = tracking1.position(rotationUnits::rev);
    // circumfence of wheels = 10.21 inches
    left_distance *= 8.639;
    float right_distance = tracking1.position(rotationUnits::rev);
    // circumfence of wheels = 10.21 inches
    right_distance *= 8.639;

    distance_trav = abs(right_distance + left_distance) / 2;

    double error = dist - (distance_trav);
    double derivative = error - prev_error;

    // if(fabs(derivative) > thresh) {
    //   stopCount++;
    // } 
    // else {
    //   stopCount = 0;
    // }

    if(fabs(error) < 1){
      driveTime += 10;
    } 
    // else {
    //   driveTime = 0;
    else if(driveTime > 15){
      break;
    }

    if(distance_trav >= dist) {
      break;
    }
    speed = error * kp + derivative * kd;
    // Drivetrains.setDriveVelocity(speed, percentUnits::pct);
    Drivetrains.drive(dir, speed, velocityUnits());

    prev_error = error;
    wait(10, msec);

  }
  tracking1.resetRotation();
  Drivetrains.stop(coast);
  return;
}

void DriveNoPID(double dist, distanceUnits units, double speed, directionType dir) {
  // int stopCount = 0;
  // double thresh = 0.5;
  // int settleTime = 5;
  // int driveTime = Drivetime;
  Drivetime.reset();

  tracking1.resetRotation();
  // RightDriveSmart.resetPosition();
  float distance_trav = 0.0;

  double kp = 1;
  double ki;
  double kd = 1;

  double prev_error = 0;

  while(true) {

    float left_distance = tracking1.position(rotationUnits::rev);
    // circumfence of wheels = 10.21 inches
    left_distance *= 8.639;
    float right_distance = tracking1.position(rotationUnits::rev);
    // circumfence of wheels = 10.21 inches
    right_distance *= 8.639;

    distance_trav = abs((right_distance + left_distance)) / 2;
    // double error = dist - (distance_trav);
   

    // if(fabs(derivative) > thresh) {
    //   stopCount++;
    // } 
    // else {
    //   stopCount = 0;
    // }

    // if(fabs(error) < 1){
      // driveTime = driveTime + 1;
    // } 
    // else {
    //   driveTime = 0;
    // }
    if(distance_trav >= dist){
      break;
    }

   if(Drivetime.time(sec) > 3) {
      // Drivetrains.stop(hold);
      Controller1.Screen.print("bob2");

      break;
    }
    
    // Drivetrains.setDriveVelocity(speed, percentUnits::pct);
    Drivetrains.drive(dir, speed, velocityUnits());

    // prev_error = error;
    wait(10, msec);

  }
  tracking1.resetRotation();
  Drivetrains.stop(hold);
  return;
}

void turnTo(turnType dir, float ang, rotationUnits units, double speed, velocityUnits speedUnits) {
Controller1.Screen.clearLine();
  tracking2.resetRotation();
  int driveTime2 = 0;

  while(true){
    driveTime2 = driveTime2 + 1;

    Drivetrains.turn(dir, speed, speedUnits);

    if(abs(tracking2.rotation(deg)) >= ang/0.5875){
      Drivetrains.stop(hold);
      Controller1.Screen.print("bob");

      break;
    }
    //  Controller1.Screen.print(driveTime2);

    if(driveTime2 > 1500) {
      Drivetrains.stop(hold);
      Controller1.Screen.print("bob2");

      break;
    }
    wait(1, msec);
  }
  // leftMotorBack.stop(hold);
  // leftMotorMiddle.stop(hold);
  // leftMotorFront.stop(hold);
  // rightMotorBack.stop(hold);
  // rightMotorMiddle.stop(hold);
  // rightMotorFront.stop(hold);
  tracking2.resetRotation();
  Drivetrains.stop(hold);

}


// void spinForw(double speed, directionType dir) {

//   while(true) {
//     double pos = punch1.position(rotationUnits()) + punch2.position(rotationUnits())/2;
//     if(punch1.position(rotationUnits()) > punch2.position(rotationUnits())+5){
//       speed -= 10;
//     } else if(punch1.position(rotationUnits()) < punch2.position(rotationUnits())-5) {
//       speed +=10;
//     }

//     if(punch2.position(rotationUnits()) > punch1.position(rotationUnits())+5){
//       speed -= 10;
//     } else if(punch2.position(rotationUnits()) < punch1.position(rotationUnits())-5) {
//       speed +=10;
//     }

//     launch.setVelocity(speed, percentUnits::pct);
//     launch.spin(dir);

//     wait(10, msec);
    
//   }
//     return;
// }

voltageUnits(volt);

void spinFlywheel() {
  flywheel.spin(forward, 500, velocityUnits(rpm));
  wait(24.5, sec);
} 

void stopFlywheel() {
  flywheel.stop(coast);
} 

void wingLOut() {
  wingL.set(true);
} 


void wingLIn() {
  wingL.set(false);
} 

void wingROut() {
  wingR.set(true);
} 


void wingRIn() {
  wingR.set(false);
} 


void wingsOut() {
  wingL.set(true);
  wingR.set(true);
} 


void wingsIn() {
  wingL.set(false);
  wingR.set(false);
} 

void slow() {
  flywheel.setVelocity(75, percent);
  
} 

void speed() {
  flywheel.setVelocity(100, percent);
  
} 

void armUp() {
  arm.spinFor(reverse, 3.7, rev, 100, velocityUnits(pct), false);
}

void armDown() {
  arm.spinFor(forward, 3.7, rev, 100, velocityUnits(pct), false);
}

void stopSkills() {
  Drivetrains.stop();
  wingsIn();
  flywheel.stop();
  arm.stop();
}

// void skillsRun() {
//   flywheel.setVelocity(99, velocityUnits(pct));
//   arm.setVelocity(90, percentUnits(pct));
//   // Firing the match Loads
//   // DriveTo(26, inches, 50, reverse);
//   Drivetrains.setStopping(coast);





//   DriveNoPID(24, inches, 75, forward);
//   wait(500, msec);
//   Drivetrains.stop(hold);
//   // DriveNoPID(35, mm, 7, forward);
//   DriveNoPID(4, inches, 20, reverse);
//   // intakePistons.set(true);
//   wait(50, msec);
//   arm.spinFor(reverse, 0.5, rev, 100, velocityUnits(pct), false);
//   intakePistons.set(false);
//   Drivetrains.stop();
//   wait(50, msec);
//   // intakePistons.set(false);

//   // turnTo(0.25, rev);
//   // turnTo(left, 85, deg, 20, velocityUnits(pct));
//   flywheel.spin(forward, 500, velocityUnits(rpm));

//   LeftDriveSmart.spinFor(-1.74, rev, 10, velocityUnits(pct));
                                                                                
//   Drivetrains.stop();

//   wingL.set(true);

//   DriveTo(5.3, inches, 50, forward);
//   // turnTo(right, 0.125, rev, 75, velocityUnits());

//   // wingR.set(true);

//   wait(21.4, seconds);


//   // Driving to the other side
//   // wingR.set(false);
//   // DriveTo(9, inches, 26, reverse);
//   // // arm.spinFor(forward, 3, sec);
//   arm.spinFor(forward, 0.5, rev, 100, velocityUnits(pct), false);
//   stopFlywheel();
//   wingL.set(false);
// }
//Function to run when the event occurs
void runOnEvent() {
  Brain.Screen.print("Event has occurred");
}

/*int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  // Register event with a callback function.
  Controller1.ButtonA.pressed(runOnEvent);

  while(true)
  {
    // Keep the main program running.
    wait(0.05, seconds);
  }
}*/