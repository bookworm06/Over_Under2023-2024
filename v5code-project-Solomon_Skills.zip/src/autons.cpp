#include "vex.h"
// #include "functions.h"
// #include "robot-config.cpp"
// #include "APS.h"

using namespace vex;
using namespace std;

// void Motion_Profile_Triangle_Turn(vector point, float acc, float dacc){
//   vector pos = vector(x_pos, y_pos)*39.37;
//   float init_angle = theta;
//   float angle =  M_PI_2 - ((point-pos).theta());
//   // std::cout << x_pos << ' ' << y_pos << ' ' << theta << ' ' << angle <<
//   '\n';

//   // std::cout <<" angle"<< angle <<"theta"<<theta<< std::endl<<std::endl;
//   float angle_error = (angle - theta)*180/M_PI;
//   // std::cout << " angle error " << angle_error << std::endl;
//   if(angle_error > 0){
//     Motion_Profile_Triangle_Turn(angle_error);
//   }
//   else{
//     Motion_Profile_Triangle_Turn_Rev(std::abs(angle_error));
//   }

// }

void TestAuton() { return; }

void leftSimple() {
  Brain.Screen.clearLine();
  Brain.resetTimer();

  wingL.set(true);
  turnTo(left, 82, deg, 20, velocityUnits(pct));
  wingL.set(false);
  // turnTo(right, 155, deg, 25, velocityUnits());
  // arm.spinFor(reverse, 0.9, rotationUnits(rev));
  wait(1, seconds);
  DriveTo(33, inches, 40, reverse);
  wait(1, seconds);
  DriveTo(5, inches, 15, reverse);

  Controller1.Screen.print("t1: %4.1f T: %4.1f", tracking1.rotation(rev), Brain.Timer.value());
}

void rightSimple() {
  Brain.resetTimer();
  DriveNoPID(27, inches, 100, reverse);
  wait(1000, msec);
  Drivetrains.stop();
  
  DriveTo(8, inches, 50, forward);
  wait(500, msec);
  turnTo(right, 45, deg, 5, velocityUnits(pct));
  DriveTo(32, inches, 50, forward);
  turnTo(right, 45, deg, 5, velocityUnits(pct));
  wait(500, msec);
  intakePistons.set(true);
  intake.spin(forward);
  Drivetrains.setStopping(hold);
  DriveTo(21, inches, 25, forward);
  // Setting the speed

  Controller1.Screen.print("t1: %4.1f T: %4.1f", tracking1.rotation(rev), Brain.Timer.value());
}

void rightHard() {
  Brain.resetTimer();

  // Setting the Speed
  Drivetrains.setDriveVelocity(100, pct);
  // Drivetrains.setTurnVelocity(50, pct);

  // Pushing the triball in the goal
  DriveTo(30, inches, 50, reverse);
  wait(100, msec);
  DriveTo(27, inches, 50, forward);

  turnToDegree(0.5, rev, 10, 20, 1.5);
  intakePistons.set(true);
  intake.spin(forward, 12, voltageUnits(volt));

  DriveTo(18, inches, 0, forward);

  // turnToDegree(0.725, rev, 15, 20, 1.5);
  // Drivetrains.driveFor(forward, 23, inches);
  // wingL.set(true);
  // wingR.set(true);
  // turnToDegree(0.1, rev, 15, 20, 1.5);
  // wingL.set(false);
  // wingR.set(false);
  // Drivetrains.driveFor(forward,10, inches);

  // Driving to touch the elevation bar

  // Touching the bar

  Brain.Screen.print(Brain.Timer.value());
}

void winPoint() {
  Brain.resetTimer();

  // Setting the Speed
  Drivetrains.setTurnVelocity(50, pct);
  Drivetrains.setDriveVelocity(50, pct);

  // Pulling out the match load
  wingL.set(true);
  turnTo(left, 40, degrees, 25, velocityUnits());
  wingL.set(false);

  // Driving to touch the elevation bar
  Drivetrains.driveFor(reverse, 23, inches);
  wait(10, msec);
  turnTo(left, 84, degrees, 25, velocityUnits());
  Drivetrains.driveFor(forward, 30, inches);

  // Touching the bar
  wingR.set(true);

  // Printing the time to the controller
  Controller1.Screen.print(" T:%4.2f", Brain.Timer.value());
  Brain.Screen.print(Brain.Timer.value());
}

void killMeNow() {
  // Prepping for the run
  Brain.resetTimer();

  flywheel.setVelocity(99, velocityUnits(pct));
  arm.setVelocity(90, percentUnits(pct));
  // Firing the match Loads
  // DriveTo(26, inches, 50, reverse);
  Drivetrains.setStopping(coast);





  DriveNoPID(24, inches, 75, forward);
  wait(500, msec);
  Drivetrains.stop(hold);
  // DriveNoPID(35, mm, 7, forward);
  DriveNoPID(4, inches, 20, reverse);
  // intakePistons.set(true);
  wait(50, msec);
  arm.spinFor(reverse, 0.5, rev, 100, velocityUnits(pct), false);
  intakePistons.set(false);
  Drivetrains.stop();
  wait(50, msec);
  // intakePistons.set(false);

  // turnTo(0.25, rev);
  // turnTo(left, 85, deg, 20, velocityUnits(pct));
  LeftDriveSmart.spinFor(-1.65, rev, 10, velocityUnits(pct));
  flywheel.spin(forward, 500, velocityUnits(rpm));


  Drivetrains.stop();

  wingL.set(true);

  DriveTo(6.1, inches, 50, forward);
  // turnTo(right, 0.125, rev, 75, velocityUnits());

  // wingR.set(true);

  wait(21.5, seconds);


  // Driving to the other side
  // wingR.set(false);
  DriveTo(10, inches, 26, reverse);
  // arm.spinFor(forward, 3, sec);
  arm.spinFor(forward, 0.5, rev, 100, velocityUnits(pct), false);
  stopFlywheel();
  wingL.set(false);


  // turnTo(0.125, rev);
  
  // LeftDriveSmart.spinFor(1, rev, 10, velocityUnits(pct), false);
  // RightDriveSmart.spinFor(-1.9, rev, 10, velocityUnits(pct));

  turnTo(right, 43, deg, 10, velocityUnits(pct));
  // turnToDegree(0.125, rev, 75, 20, 1.5);
  DriveTo(19.9, inches, 25, reverse);
  turnTo(left, 28, deg, 10, velocityUnits(pct));

  // turnTo(-0.125, rev);
  // LeftDriveSmart.spinFor(-1.5, rev, 10, velocityUnits(pct));
  // RightDriveSmart.spinFor(1, rev, 10, velocityUnits(pct));  
  // turnToDegree(-0.125, rev, 75, 20, 1.5);

  // Pusing in the triball on the right side
  DriveTo(79, inches, 70, reverse);
  // turnTo(-0.125, rev);
  turnTo(left, 38, deg, 5, velocityUnits(pct));
  // turnToDegree(-0.125, rev, 75, 20, 1.5);
  DriveNoPID(22.4, inches, 100, reverse);
  DriveNoPID(8, inches, 25, forward);
  DriveNoPID(8, inches, 100, reverse);
  DriveNoPID(8, inches, 25, forward);
  DriveNoPID(8, inches, 100, reverse);
  Drivetrains.stop();
  wait(500, msec);
  DriveTo(8, inches, 25, forward);

  turnTo(left, 40, deg, 20, velocityUnits(pct));
  DriveNoPID(38.4, inches, 25, reverse);
    wingsOut();
  turnTo(left, 17, deg, 10, velocityUnits());
  DriveNoPID(26.4, inches, 100, forward);
  turnTo(right, 11, deg, 10, velocityUnits());

  DriveNoPID(22.4, inches, 25, reverse);
  turnTo(left, 11, deg, 10, velocityUnits());
  DriveNoPID(23.4, inches, 100, forward);
  turnTo(left, 11, deg, 10, velocityUnits());

  DriveNoPID(22.4, inches, 25, reverse);
  turnTo(right, 11, deg, 10, velocityUnits());
  DriveNoPID(23.4, inches, 100, forward);
  DriveNoPID(9.4, inches, 100, reverse);

  Controller1.Screen.print("t1: %4.1f T: %4.1f", tracking1.rotation(rev), Brain.Timer.value());
  Brain.Screen.print("t1: %4.1f T: %4.1f", tracking1.rotation(rev), Brain.Timer.value());
}

void leftHard() {
  Brain.resetTimer();

  /*Here*/
  // Drivetrains.turnFor(90, deg);

  flywheel.spin(forward, 500, velocityUnits(rpm));
  wait(10, sec);
  flywheel.stop();
  // turnTo(left, 90, deg, 20, velocityUnits(pct));
  // wait(1, sec);
  // turnTo(right, 90, deg, 20, velocityUnits(pct));



  // wingL.set(true);
  // turnToDegree(0.5, rev, 4, 20, 1.5);
  // wingL.set(false);
  // turnToDegree(0.05, rev, 4, 20, 1.5);
  // intakePistons.set(true);
  // intake.spin(reverse, 12, voltageUnits(volt));
  // DriveTo(12, inches, 0, forward);

  /*and Here*/

  // Setting the speed
  // Drivetrains.setTurnVelocity(40, pct);
  // Drivetrains.setDriveVelocity(40, pct);

  // //removing the match load
  // wingR.set(true);
  // turnToDegree(-0.25, rev, 15, 20, 1.5);
  // wingR.set(false);

  // Drivetrains.driveFor(reverse, 20, inches);
  // turnToDegree(-0.975, rev, 15, 20, 1.5);
  // Drivetrains.driveFor(forward, 12, inches);
  // turnToDegree(-0.75, rev, 15, 20, 1.5);
  // Drivetrains.driveFor(forward, 26, inches);
  // turnToDegree(0.95, rev, 15, 20, 1.5);
  // Drivetrains.driveFor(forward, 26, inches);
  // wingL.set(true);
  Controller1.Screen.clearLine();
  Controller1.Screen.print(tracking2.rotation(deg));
}

void no() {
  //   // Optical5.getRgb();
  //   // Optical5.hue();
  //   Optical5.brightness(100);
  //   Optical5.setLightPower(100);
  //   Optical5.color() = red;
  //   if(Optical5.color() >= 0 and Optical5.color() <= 100) {
  //   Inroller.spin(forward);
  //   }

  //   if(Optical5.brightness() == 100){

  //   }

  //   if(Optical5.color() == vex::color::red) {
  //   Inroller.spin(forward);
  //   }
  // // Optical5.getRgb();
  // optical::rgbc color1 = Optical5.getRgb();
  // optical::rgbc color2;

  // color2.red = 255; //<--change to whatever color you need to check for
  // color2.green = 0; //<--change to whatever color you need to check for
  // color2.blue = 0; //<--change to whatever color you need to check for

  // if((color1.red == color2.red) and (color1.green == color2.green) and
  // (color1.blue == color2.blue)) {
  //   Inroller.spin(forward);
  // }
  // if (color1 == 255){
  //   Roller.spin(forward);
  // }
  // bool yay = true;
  // while(yay == true){
  //   wait(4.2, seconds);
  //   Intake.spinFor(forward, 5.4, degrees);
  //   wait(5.8, seconds);
  //   Drivetrain.driveFor(reverse, 5.7, mm);
  //   wait(2.3, seconds);
  //   Roller.spinFor(reverse, 29, degrees);
  // }
}
