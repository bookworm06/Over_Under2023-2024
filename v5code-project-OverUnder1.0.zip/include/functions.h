#ifndef FUNCTIONS_H
#define FUNCTIONS_H

using namespace vex;
 void Drive(double distace, distanceUnits units, double speed, directionType dir);
 void WinDrive(double distace, distanceUnits units, double speed, directionType dir);
 void runOnEvent();

 
#endif