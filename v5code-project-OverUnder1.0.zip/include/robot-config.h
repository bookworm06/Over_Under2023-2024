using namespace vex;

extern brain Brain;

using signature = vision::signature;

// VEXcode devices
extern drivetrain Drivetrain;
extern motor_group LeftDriveSmart;
extern motor_group RightDriveSmart;
extern motor leftMotorBack;
extern motor rightMotorBack;
extern controller Controller1;
extern motor lift;
extern motor Sling2;
extern motor Intake1;
// extern motor Intake2;
// extern signature Vision__RED_SIDE;
// extern signature Vision__BLUE_SIDE;
extern signature Vision__SIG_3;
extern signature Vision__SIG_4;
extern signature Vision__SIG_5;
extern signature Vision__SIG_6;
extern signature Vision__SIG_7;
// extern vision Vision;
// extern motor Roller;
extern digital_out pneumatics;
extern digital_out PTO;
extern digital_out balence;
extern optical Optical5;
extern inertial Inertial17;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );