#include "vex.h" 
#include "functions.h"

using namespace vex;

void Drive(double dist, distanceUnits units, double speed, directionType dir) {
  // int stopCount = 0;
  // double thresh = 0.5;
  // int settleTime = 5;
  int driveTime = 0;

  LeftDriveSmart.resetPosition();
  RightDriveSmart.resetPosition();
  double distance_trav = 0.0;

  double kp = 1.5;
  double ki;
  double kd = 1;

  double prev_error = 0;

  while(true) {

    double left_distance = LeftDriveSmart.position(rotationUnits::rev);
    // circumfence of wheels = 10.21 inches
    left_distance *= 12.56;
    double right_distance = RightDriveSmart.position(rotationUnits::rev);
    // circumfence of wheels = 10.21 inches
    right_distance *= 12.56;

    distance_trav = (right_distance + left_distance) / 2;

    double error = dist - distance_trav;
    double derivative = error - prev_error;

    // if(fabs(derivative) > thresh) {
    //   stopCount++;
    // }
    // else {
    //   stopCount = 0;
    // }

    if(fabs(error) < 1){
      driveTime += 10;
    } 
    else {
      driveTime = 0;
    }
    if(driveTime > 200){
      break;
    }

    // if(stopCount > settleTime) {
    //   break;
    // }
    speed = error * kp + derivative * kd;
    Drivetrain.setDriveVelocity(speed, percentUnits::pct);
    Drivetrain.drive(dir);

    prev_error = error;
    wait(10, msec);

  }
  Drivetrain.stop();
  return;
}

void WinDrive(double dist, distanceUnits units, double speed, directionType dir) {
  // int stopCount = 0;
  // double thresh = 0.5;
  // int settleTime = 5;
  int driveTime = 0;

  LeftDriveSmart.resetPosition();
  RightDriveSmart.resetPosition();
  double distance_trav = 0.0;

  double kp = 1;
  double ki;
  double kd = 1;

  double prev_error = 0;

  while(true) {

    double left_distance = LeftDriveSmart.position(rotationUnits::rev);
    // circumfence of wheels = 10.21 inches
    left_distance *= 12.96;
    double right_distance = RightDriveSmart.position(rotationUnits::rev);
    // circumfence of wheels = 10.21 inches
    right_distance *= 12.96;

    distance_trav = (right_distance + left_distance) / 2;

    double error = dist - distance_trav;
    double derivative = error - prev_error;

    // if(fabs(derivative) > thresh) {
    //   stopCount++;
    // }
    // else {
    //   stopCount = 0;
    // }

    if(fabs(error) < 1){
      driveTime += 10;
    } 
    else {
      driveTime = 0;
    }
    if(driveTime > 200){
      break;
    }

    // if(stopCount > settleTime) {
    //   break;
    // }
    speed = error * kp + derivative * kd;
    Drivetrain.setDriveVelocity(speed, percentUnits::pct);
    Drivetrain.drive(dir);

    prev_error = error;
    wait(10, msec);

    if(prev_error <= 0){
      break;
    }
  }
  Drivetrain.stop();
  return;
}

//Function to run when the event occurs
void runOnEvent() {
  Brain.Screen.print("Event has occurred");
}

/*void pressed() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  // Register event with a callback function.
  Controller1.ButtonA.pressed(runOnEvent);

  while(true)
  {
    // Keep the main program running.
    wait(0.05, seconds);
  }
}*/