#include "vex.h"
// #include "functions.h"
// #include "robot-config.cpp"
// #include "APS.h"

using namespace vex;
using namespace std;

// void Motion_Profile_Triangle_Turn(vector point, float acc, float dacc){
//   vector pos = vector(x_pos, y_pos)*39.37;
//   float init_angle = theta;
//   float angle =  M_PI_2 - ((point-pos).theta());
//   // std::cout << x_pos << ' ' << y_pos << ' ' << theta << ' ' << angle << '\n';
//   // std::cout <<" angle"<< angle <<"theta"<<theta<< std::endl<<std::endl;
//   float angle_error = (angle - theta)*180/M_PI;
//   // std::cout << " angle error " << angle_error << std::endl;
//   if(angle_error > 0){
//     Motion_Profile_Triangle_Turn(angle_error);
//   }
//   else{
//     Motion_Profile_Triangle_Turn_Rev(std::abs(angle_error));
//   }

// }

void TestAuton() {
  return;
}

void leftSimple() {
  Brain.resetTimer();
  punch1.setVelocity(100, percent);
  punch2.setVelocity(100, percent);

  Brain.Screen.print(Brain.Timer.value());
}

void rightSimple() {
  Brain.resetTimer();

  //Setting the speed
  Drivetrains.setDriveVelocity(50, pct);
  Drivetrains.setTurnVelocity(50, pct);

  //Guiding the triball
  leftArm.set(true);
  rightArm.set(true);

  //Pushing the triball in the goal
  Drivetrains.driveFor(forward, 34.5, inches);
  wait(50, msec);

  Brain.Screen.print(Brain.Timer.value());
}

void rightHard() { 
  Brain.resetTimer();

  //Setting the Speed
  Drivetrains.setDriveVelocity(50, pct);
  Drivetrains.setTurnVelocity(50, pct);

  //Guiding the triball
  leftArm.set(true);
  rightArm.set(true);

  //Pushing the triball in the goal
  Drivetrains.driveFor(forward, 34.5, inches);
  wait(50, msec);

  //Driving to touch the elevation bar
  Drivetrains.driveFor(reverse, 8.5, inches);
  leftArm.set(false);
  rightArm.set(false);
  Drivetrains.turnFor(left, 107, degrees);
  Drivetrains.driveFor(forward, 45, inches);

  //Touching the bar
  leftArm.set(true);

  Brain.Screen.print(Brain.Timer.value());
}

void winPoint() {
  Brain.resetTimer();

  //Setting the Speed
  Drivetrains.setTurnVelocity(50, pct);
  Drivetrains.setDriveVelocity(50, pct);

  // Firing the triball
  launch.setVelocity(50, pct);
  launch.spinFor(100, degrees);

  //Pulling out the match load
  leftArm.set(true);
  Drivetrains.turnFor(left, 40, degrees);
  leftArm.set(false);

  //Driving to touch the elevation bar
  Drivetrains.driveFor(reverse, 23, inches);
  wait(10, msec);
  Drivetrains.turnFor(left, 84, degrees);
  Drivetrains.driveFor(forward, 30, inches);

  //Touching the bar
  rightArm.set(true);

  //Printing the time to the controller
  Controller1.Screen.print(" T:%4.2f", Brain.Timer.value());
  Brain.Screen.print(Brain.Timer.value());
}

void killMeNow() {
  //Prepping for the run
  Brain.resetTimer();
  launch.setVelocity(100, percentUnits(pct));

  //Firing the match Loads
  // leftArm.set(true);
  // launch.spinFor(forward, 33, sec);
  leftArm.set(false);

  //Driving to the other side
  Drivetrains.driveFor(reverse, 1, inches);
  Drivetrains.turnFor(right, 26, degrees, 50, velocityUnits());
  Drivetrains.driveFor(reverse, 74, inches, 75, velocityUnits());

  //Pusing in the triball on the right side
  Drivetrains.turnFor(left, 48, degrees, 50, velocityUnits());
  Drivetrains.driveFor(reverse, 40.5, inches, 65, velocityUnits());

  //Driving to the front of the goal
  Drivetrains.driveFor(forward, 5, inches, 50, velocityUnits());
  Drivetrains.turnFor(right, 32, deg, 65, velocityUnits());
  Drivetrains.driveFor(forward, 40, inches, 65, velocityUnits());
  wait(100, msec);
  Drivetrains.turnFor(right, 95, deg, 65, velocityUnits());

  //Pusing the triballs in the goal
  wings.set(true);
  Drivetrains.driveFor(forward, 40.5, inches, 90, velocityUnits());

  
  Brain.Screen.print(Brain.Timer.value());
}

void leftHard() {
  Brain.resetTimer();

  //Setting the speed
  Drivetrains.setTurnVelocity(50, pct);
  Drivetrains.setDriveVelocity(50, pct);
  launch.setVelocity(50, pct);

  //removing the match load
  rightArm.set(true);
  Drivetrains.turnFor(left, 40, degrees);
  rightArm.set(false);

  //Driving to fire the triball
  Drivetrains.driveFor(reverse, 23, inches);
  wait(10, msec);
  Drivetrains.turnFor(right, 65, degrees);
  Drivetrains.driveFor(forward, 10, inches);

  //Firing the triball and touching the elevation bar
  launch.spinFor(100, degrees);
  Drivetrains.driveFor(reverse, 46, inches);
  Drivetrains.turnFor(left, 88, degrees);
  Drivetrains.driveFor(forward, 12, inches);
  leftArm.set(true);

  Brain.Screen.print(Brain.Timer.value());
}

void no() {
  //   // Optical5.getRgb();
  //   // Optical5.hue();
  //   Optical5.brightness(100);
  //   Optical5.setLightPower(100);
  //   Optical5.color() = red;
  //   if(Optical5.color() >= 0 and Optical5.color() <= 100) {
  //   Inroller.spin(forward);
  //   }

  //   if(Optical5.brightness() == 100){
      
  //   }
    
  //   if(Optical5.color() == vex::color::red) {
  //   Inroller.spin(forward);
  //   }
  // // Optical5.getRgb();
  // optical::rgbc color1 = Optical5.getRgb(); 
  // optical::rgbc color2;


  // color2.red = 255; //<--change to whatever color you need to check for
  // color2.green = 0; //<--change to whatever color you need to check for
  // color2.blue = 0; //<--change to whatever color you need to check for

  // if((color1.red == color2.red) and (color1.green == color2.green) and (color1.blue == color2.blue)) {
  //   Inroller.spin(forward);
  // }
  // if (color1 == 255){
  //   Roller.spin(forward);
  // }
    // bool yay = true;
    // while(yay == true){
    //   wait(4.2, seconds);
    //   Intake.spinFor(forward, 5.4, degrees);
    //   wait(5.8, seconds);
    //   Drivetrain.driveFor(reverse, 5.7, mm);
    //   wait(2.3, seconds);
    //   Roller.spinFor(reverse, 29, degrees);
    // }
}
