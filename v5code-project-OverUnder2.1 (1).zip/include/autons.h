#ifndef AUTONS_H
#define AUTONS_H

void TestAuton();


void leftRed();
void rightr();
void winPoint();
void prank();
void killMeNow();

#endif