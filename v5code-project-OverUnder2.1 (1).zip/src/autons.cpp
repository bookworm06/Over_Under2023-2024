#include "vex.h"
#include "functions.h"
// #include "robot-config.cpp"
// #include "APS.h"

using namespace vex;
using namespace std;

// void Motion_Profile_Triangle_Turn(vector point, float acc, float dacc){
//   vector pos = vector(x_pos, y_pos)*39.37;
//   float init_angle = theta;
//   float angle =  M_PI_2 - ((point-pos).theta());
//   // std::cout << x_pos << ' ' << y_pos << ' ' << theta << ' ' << angle << '\n';
//   // std::cout <<" angle"<< angle <<"theta"<<theta<< std::endl<<std::endl;
//   float angle_error = (angle - theta)*180/M_PI;
//   // std::cout << " angle error " << angle_error << std::endl;
//   if(angle_error > 0){
//     Motion_Profile_Triangle_Turn(angle_error);
//   }
//   else{
//     Motion_Profile_Triangle_Turn_Rev(std::abs(angle_error));
//   }

// }

void TestAuton() {
  return;
}

void leftRed() {
  Brain.resetTimer();

  Brain.Screen.print(Brain.Timer.value());
}

void rightr() {
  Brain.resetTimer();

  Brain.Screen.print(Brain.Timer.value());
}

void winPoint() {
  Brain.resetTimer();
  Brain.Screen.print(Brain.Timer.value());
}

void killMeNow() {
  //Prepping for the run
  Brain.resetTimer();

  Brain.Screen.print(Brain.Timer.value());
}

void prank() {
  //   Brain.resetTimer();
  //   bool joke = true;
  //   while(joke == true){
  //     FlyWheel.spin(reverse, 12, volt);
  //     Intake1.spin(reverse, 12, volt);
  //     balence.set(true);
  //     wait(5, sec);
  //     balence.set(false);
  //     wait(5, sec);
  //     Brain.Screen.print(FlyWheel.voltage());
}

void no() {
  //   // Optical5.getRgb();
  //   // Optical5.hue();
  //   Optical5.brightness(100);
  //   Optical5.setLightPower(100);
  //   Optical5.color() = red;
  //   if(Optical5.color() >= 0 and Optical5.color() <= 100) {
  //   Inroller.spin(forward);
  //   }

  //   if(Optical5.brightness() == 100){
      
  //   }
    
  //   if(Optical5.color() == vex::color::red) {
  //   Inroller.spin(forward);
  //   }
  // // Optical5.getRgb();
  // optical::rgbc color1 = Optical5.getRgb(); 
  // optical::rgbc color2;


  // color2.red = 255; //<--change to whatever color you need to check for
  // color2.green = 0; //<--change to whatever color you need to check for
  // color2.blue = 0; //<--change to whatever color you need to check for

  // if((color1.red == color2.red) and (color1.green == color2.green) and (color1.blue == color2.blue)) {
  //   Inroller.spin(forward);
  // }
  // if (color1 == 255){
  //   Roller.spin(forward);
  // }
    // bool yay = true;
    // while(yay == true){
    //   wait(4.2, seconds);
    //   Intake.spinFor(forward, 5.4, degrees);
    //   wait(5.8, seconds);
    //   Drivetrain.driveFor(reverse, 5.7, mm);
    //   wait(2.3, seconds);
    //   Roller.spinFor(reverse, 29, degrees);
    // }
}