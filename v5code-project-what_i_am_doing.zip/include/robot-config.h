using namespace vex;

extern brain Brain;

using signature = vision::signature;

// VEXcode devices
extern drivetrain Drivetrains;
// extern inertial inertial1;
// extern inertial inertial12;
// extern inertial inertial13;
extern motor_group LeftDriveSmart;
extern motor_group RightDriveSmart;
extern motor leftMotorBack;
extern motor rightMotorBack;
extern motor leftMotorMiddle;
extern motor rightMotorMiddle;
extern motor leftMotorFront;
extern motor rightMotorFront;
extern controller Controller1;
extern motor arm;
extern motor intake;
extern rotation trackingM;
extern rotation trackingR;
extern rotation trackingL;
extern rotation armDeg;
extern digital_out clamp;
extern digital_out and_we_and_lift_off;
extern digital_out intake_lift;
extern digital_out doinker;
extern inertial angleTracking;
extern inertial angleTracking2;

extern bumper positionButton;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );