/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <algorithm>

using namespace vex;

/*
 Pi is a number that never ends
 It goes on and on in twists and bends
 It hides within its digits many mysteries
 Like the shape of circles and the area of spheres 
 It has inspired mathematicians for centuries 
 To explore its patterns and its properties 
 It is more than just a number, it is a symbol 
 Of the beauty and the wonder of the world
*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    20, 18, 17, 10, 3, 4   
// Controller1          controller                    
// Arm                  motor         19            
// Intake               motor         16                                            
// pneumatics           digital_out   A 
// pneumatics           digital_out   H
// ---- END VEXCODE CONFIGURED DEVICES ----


#include "vex.h"

using namespace vex;

// Constants for tracking and movement
const double WHEEL_CIRCUMFERENCE = 2.75 * M_PI; // Wheel circumference in inches
const double TICKS_PER_REV = 360.0; // Encoder ticks per wheel revolution
const double TRACKING_TICK_TO_INCH = WHEEL_CIRCUMFERENCE / TICKS_PER_REV; // Conversion factor from encoder ticks to inches
const double TURN_KP = 0.5;      //
const double TURN_KI = 0.0001;   // PID constants for turning
const double TURN_KD = 0.1;      // 

const double DRIVE_KP = 0.6;     //
const double DRIVE_KI = 0.0001;  // PID constants for driving
const double DRIVE_KD = 0.2;     // 

// Sensor offsets
const double ROTATION_SENSOR_OFFSET = 0.125;
const double INERTIAL1_OFFSET = 0.5;
const double INERTIAL2_OFFSET = 3.625;
const double INERTIAL_DISTANCE = 4.25;
float currentPosition = 0;

const double MIN_DRIVE_POWER = 5.0; // Minimum power to ensure movement
const int TIMEOUT_MS = 5000; // Timeout to prevent infinite loops

// Structure to track the robot's position
struct Position {
    double x = 0.0; // X coordinate in inches
    double y = 0.0; // Y coordinate in inches
    double headingCurrent = 0.0; // Heading in degrees
} robotPos;

double getAveragedHeading() {
    return (angleTracking.rotation() + angleTracking2.rotation()) / 2.0;
}

// Function to update odometry based on sensor readings
void setInitialPosition(double startX, double startY, double startHeading) {
    robotPos.x = startX;
    robotPos.y = startY;
    robotPos.headingCurrent = startHeading;
    angleTracking.setRotation(startHeading, degrees); // Ensure heading is consistent
    angleTracking2.setRotation(startHeading, degrees); // Ensure heading is consistent
}

void updateOdometry() {
    static double lastEncoderPosition = 0;
    double currentEncoderPosition = trackingR.position(degrees) * TRACKING_TICK_TO_INCH; // Convert encoder ticks to inches
    double deltaDist = currentEncoderPosition - lastEncoderPosition;
    lastEncoderPosition = currentEncoderPosition;
    
    double headingRad = angleTracking.rotation() * (M_PI / 180.0); // Convert heading to radians for calculations
    
    // Update position using field-relative trigonometry
    robotPos.x += deltaDist * cos(headingRad);
    robotPos.y += deltaDist * sin(headingRad);
    robotPos.headingCurrent = angleTracking.rotation(); // Keep absolute heading tracking
    printf("Odometry - X: %.2f, Y: %.2f, Heading: %.2f\n", robotPos.x, robotPos.y, robotPos.headingCurrent);

}


// Generic PID controller function
double PID(float error, float &prevError, float &integral, float kp, float ki, float kd) {
    integral += error; // Accumulate integral term
    double derivative = error - prevError; // Compute derivative term
    prevError = error; // Store current error for next iteration
    return (kp * error) + (ki * integral) + (kd * derivative); // Compute PID output
}

/*

// Function to drive the robot to a target coordinate
void driveTo(double targetX, double targetY) {
    float error;
    float prevError = 0;
    float integral = 0;
    double distances = sqrt(pow(targetX - robotPos.x, 2) + pow(targetY - robotPos.y, 2)); // Calculate initial distance to target
    
    while (fabs(distances) > 1) { // Continue until the robot is close to the target
        error = distances;
        double motorPower = PID(error, prevError, integral, DRIVE_KP, DRIVE_KI, DRIVE_KD); // Compute PID output
        
        // Apply power to drive motors
        LeftDriveSmart.spin(forward, motorPower*0.07, percent);
        RightDriveSmart.spin(forward, motorPower*0.07, percent);
        
        updateOdometry(); // Update robot position
        
        // Recalculate distance after movement
        distances = sqrt(pow(targetX - robotPos.x, 2) + pow(targetY - robotPos.y, 2));
        printf("Moving - X: %.2f, Y: %.2f, Distance: %.2f\n", robotPos.x, robotPos.y, distances);

        wait(20, msec); // Small delay to prevent excessive updates
        printf("X: %.2f Y: %.2f", robotPos.x, robotPos.y);
        
        if((robotPos.x-1 <= targetX && targetX >= robotPos.x+1) && (robotPos.y-1 <= targetY && targetY >= robotPos.y+1)){
          break;
        }
    }
    
    // Stop motors when the target is reached
    LeftDriveSmart.stop();
    RightDriveSmart.stop();
    printf("Reached Target - X: %.2f, Y: %.2f\n", robotPos.x, robotPos.y);

    printf("X: %.2f Y: %.2f", robotPos.x, robotPos.y);
}
*/

// Function to turn the robot to a specified angle
void turnTo(double targetAngle, float reduction) {
  //PID Constants
  float kP = 0.25;
  float kI = 0.01;
  float kD = 0.785;
      
  //PID Turn Variables
  float error = 0;
  float integral = 0;
  float derivative = 0;
  float prevError = 0;

  //Motor Power Variables
  float motorPower = 0;
  float prevMotorPower = 0;

  float startAngle = angleTracking.rotation(degrees);

  while(true) {
    float currentAngle = startAngle - angleTracking.rotation(degrees);

    //Upadating all the PID Turn Varibles
    error = targetAngle - currentAngle;

    if (error < 10 && error > -10) {
      integral += error;
    }

    derivative = error - prevError;
    //Calculating the PID
    motorPower = ((kP * error) + (kI * integral) + (kD * derivative))*reduction;
    // motorPower = PID(error, prevError, integral, kP, kI, kD);

    //Spinning the motors
    if (motorPower > 1) motorPower = 1;
    if (motorPower < -1) motorPower = -1;

    leftMotorFront.spin(forward, -11 * motorPower, volt);
    leftMotorMiddle.spin(forward, -11 * motorPower, volt);
    leftMotorBack.spin(forward, -11 * motorPower, volt);
    rightMotorFront.spin(forward, 11 * motorPower, volt);
    rightMotorMiddle.spin(forward, 11 * motorPower, volt);
    rightMotorBack.spin(forward, 11 * motorPower, volt);

    //Chacking to see if the error is less under 2 degrees and if so breaking the loop
    if (error > -2 && error < 2 && error - prevError > -0.3 && error - prevError < 0.3) {
      break;
    }

    prevMotorPower = motorPower;
    prevError = error;

    wait(20, msec);
  }

  //Stopping the robot
  leftMotorFront.stop();
  leftMotorMiddle.stop();
  leftMotorBack.stop();
  rightMotorFront.stop();
  rightMotorMiddle.stop();
  rightMotorBack.stop();
  wait(200, msec);
      
}

//This drive function does not stop when driving.
int drivePID(directionType direction, float driveDistanceInches, float reduction) {
  Brain.Timer.reset();
  double bob = 0;
  
  // PID Constants for Driving
  const float kP = 0.19;
  const float kI = 0.0;
  const float kD = 0.70;

  // PID Constants for Heading Correction
  const float angle_kP = 0.05;  // Small proportional correction factor

  // PID Variables for Driving
  float error = 0;
  float integral = 0;
  float derivative = 0;
  float prevError = 0;

  // Motor Power Variables
  float motorPower = 0;
  float prevMotorPower = 0;

  // Get Initial Heading
  float initialHeading = getAveragedHeading(); 

  // Reset Encoder
  trackingR.setPosition(0.0, degrees);

  // Convert drive distance from inches to degrees
  float wheelCircumference = 2.0 * 3.141592653589793;
  float degreePerInch = 360.0 / wheelCircumference;
  float driveDistance = driveDistanceInches * degreePerInch;

  while (true) {
    bob = Brain.Timer.time(msec); 

    // Read current distance traveled
    float currentDistance = fabs(trackingR.position(degrees));

    // Calculate drive error
    error = driveDistance - currentDistance;

    // Accumulate error for integral term if within range
    if (error < 2) {
      integral += error;
    }

    // Compute derivative term
    derivative = error - prevError;

    // Calculate base motor power using drive PID
    motorPower = ((kP * error) + (kI * integral) + (kD * derivative)) * reduction;

    // Clamp motor power
    if (motorPower > 1) motorPower = 1;
    if (motorPower < -1) motorPower = -1;

    // **Angle Correction Logic**
    float currentHeading = getAveragedHeading();
    float angleError = initialHeading - currentHeading; // Difference between initial and current heading
    float turnCorrection = angleError * angle_kP; // Small correction factor

    // Apply power with angle correction
    float leftPower = motorPower + turnCorrection;
    float rightPower = motorPower - turnCorrection;

    // Clamp power values
    leftPower = fmin(fmax(leftPower, -1), 1);
    rightPower = fmin(fmax(rightPower, -1), 1);

    // Drive motors with correction
    LeftDriveSmart.spin(direction, 11 * leftPower, volt);
    RightDriveSmart.spin(direction, 11 * rightPower, volt);

    // Debugging output
    printf("Error: %f, Angle Error: %f, Left Power: %f, Right Power: %f\n", error, angleError, leftPower, rightPower);

    // Exit conditions
    if (fabs(error) < 200 && fabs(error) - prevError < 10) break;
    if (driveDistance <= currentDistance) break;
    if (fabs(error) < 200 && error > -200) break;
    if (bob >= 2500) break;

    // Update previous values
    prevMotorPower = motorPower;
    prevError = error;

    wait(20, msec);
  }

  // Stop all drive motors
  Drivetrains.stop(hold);
  wait(200, msec);
  return 0;
}
/*
void angleCorrecting(double targetY, double targetX){
    double deltaX = targetX - robotPos.x;
    double deltaY = targetY - robotPos.y;
    double targetAngle = atan2(deltaY, deltaX) * (180.0 / M_PI); // Convert to degrees
    
    // Determine if driving backward is more efficient
    
    // Turn to face the target (absolute heading reference)
    float error;
    float prevError = 0;
    float integral = 0;
    int startTime = vex::timer::system(); // Start timer
    while (fabs(targetAngle - robotPos.headingCurrent) > 0.5 && vex::timer::system() - startTime < TIMEOUT_MS) { // Timeout protection
        error = targetAngle - robotPos.headingCurrent; // Compute angular error
        double motorPower = PID(error, prevError, integral, TURN_KP, TURN_KI, TURN_KD); // Compute PID output
        
        // Apply turning power to drive motors
        LeftDriveSmart.spin(forward, motorPower, percent);
        RightDriveSmart.spin(reverse, motorPower, percent);
        
        updateOdometry(); // Update odometry to keep position accurate
        wait(10, msec); // Small delay to improve accuracy
    }
    
    // Stop motors once target angle is reached
    LeftDriveSmart.stop();
    RightDriveSmart.stop();
}
*/
// Move to function
void moveTo(double targetX, double targetY, double reduction, directionType dirrection) {
    // Calculate angle to target
    double deltaX = targetX - robotPos.x;
    double deltaY = targetY - robotPos.y;
    double targetAngle = atan2(targetX - robotPos.x, targetY - robotPos.y) * (180.0 / M_PI);

    // Turn to face target
    turnTo(targetAngle, 0.1);
    
    // Calculate distance to target
    double distances = sqrt(deltaX * deltaX + deltaY * deltaY);
        
    // while (distances > 2.0) { // Continue adjusting while moving
        updateOdometry();
    //     deltaX = targetX - robotPos.x;
    //     deltaY = targetY - robotPos.y;
    //     targetAngle = atan2(deltaY, deltaX) * (180.0 / M_PI);
    //     distances = sqrt(deltaX * deltaX + deltaY * deltaY);
        
    //     double currentHeading = getAveragedHeading();
    //     double headingError = targetAngle - currentHeading;
        
    //     // Apply small corrections if the robot deviates from the path
    //     if (fabs(headingError) > 2.0) {
    //         angleCorrecting( targetY,  targetX); // Small correction turns
    //     }
    // }

    // Drive to target
    drivePID(dirrection, distances, reduction);

    setInitialPosition(targetX, targetY, targetAngle);

}

/*
  // Function to move to a coordinate by turning first, then driving
  void moveTo(double targetX, double targetY, bool driveBackward, double speed = 100.0) {
      // Calculate the angle to the target point (global field coordinates)
      double deltaX = targetX - robotPos.x;
      double deltaY = targetY - robotPos.y;
      double targetAngle = atan2(deltaY, deltaX) * (180.0 / M_PI); // Convert to degrees
      
      // Determine if driving backward is more efficient
      double angleDifference = targetAngle - robotPos.headingCurrent;
      // bool driveBackward = false;
      if (fabs(angleDifference) > 90 && driveBackward == true) { 
          targetAngle += 180; // Adjust angle to drive backward
          if (targetAngle > 180) targetAngle -= 360;
          if (targetAngle < -180) targetAngle += 360;
          // driveBackward = true;
      }
      
      // Turn to face the target (absolute heading reference)
      float error;
      float prevError = 0;
      float integral = 0;
      int startTime = vex::timer::system(); // Start timer
      while (fabs(targetAngle - robotPos.headingCurrent) > 0.5 && vex::timer::system() - startTime < TIMEOUT_MS) { // Timeout protection
          error = targetAngle - robotPos.headingCurrent; // Compute angular error
          double motorPower = PID(error, prevError, integral, TURN_KP, TURN_KI, TURN_KD); // Compute PID output
          
          // Apply turning power to drive motors
          LeftDriveSmart.spin(forward, motorPower, percent);
          RightDriveSmart.spin(reverse, motorPower, percent);
          
          updateOdometry(); // Update odometry to keep position accurate
          wait(10, msec); // Small delay to improve accuracy
      }
      
      // Stop motors once target angle is reached
      LeftDriveSmart.stop();
      RightDriveSmart.stop();
      
      // Drive to the target position while continuously adjusting heading
      double distances = sqrt(deltaX * deltaX + deltaY * deltaY); // Calculate distance to target
      prevError = 0;
      integral = 0;
      startTime = vex::timer::system(); // Reset timer
      
      while (fabs(distances) > 2.0 && vex::timer::system() - startTime < TIMEOUT_MS) { // Timeout protection
          // Recalculate distance and heading error
          deltaX = targetX - robotPos.x;
          deltaY = targetY - robotPos.y;
          distances = sqrt(deltaX * deltaX + deltaY * deltaY);
          double headingError = targetAngle - robotPos.headingCurrent;
          
          // Compute PID output for driving and heading correction
          double drivePower = PID(distances, prevError, integral, DRIVE_KP, DRIVE_KI, DRIVE_KD);
          double turnPower = PID(headingError, prevError, integral, TURN_KP, TURN_KI, TURN_KD);
          
          // drivePower = fmin(drivePower, speed); // Limit speed to max speed parameter
          if (distances <= 2.0) drivePower *= 0.5; // Slow down near target
          
          // Apply power to drive motors with heading correction
          if (driveBackward) {
              LeftDriveSmart.spin(reverse, drivePower - turnPower, percent);
              RightDriveSmart.spin(reverse, drivePower + turnPower, percent);
          } else {
              LeftDriveSmart.spin(forward, drivePower + turnPower, percent);
              RightDriveSmart.spin(forward, drivePower - turnPower, percent);
          }
          
          updateOdometry(); // Update robot position
          wait(10, msec); // Small delay to improve accuracy
      }
      
      // Stop motors when the target is reached
      LeftDriveSmart.stop();
      RightDriveSmart.stop();
      
      printf("Reached Target - X: %.2f, Y: %.2f\n", robotPos.x, robotPos.y);
  }

  // Function to move to a coordinate by turning first, then driving
  void moveTow(double targetX, double targetY) {
      // Calculate the angle to the target point
      double deltaX = targetX - robotPos.x;
      double deltaY = targetY - robotPos.y;
      double targetAngle = atan2(deltaY, deltaX) * (180.0 / M_PI); // Convert to degrees
      
      // Turn to face the target
      float error;
      float prevError = 0; 
      float integral = 0;
      angleTracking.setRotation(0, degrees); // Reset inertial sensor rotation reference
      
      while (fabs(targetAngle - robotPos.headingCurrent) > 1) { // Continue until within 1 degree of target
          error = targetAngle - robotPos.headingCurrent; // Compute angular error
          double motorPower = PID(error, prevError, integral, TURN_KP, TURN_KI, TURN_KD); // Compute PID output
          
          // Apply turning power to drive motors
          LeftDriveSmart.spin(forward, motorPower, percent);
          RightDriveSmart.spin(reverse, motorPower, percent);
          
          robotPos.headingCurrent = angleTracking.rotation(degrees); // Update heading from sensor
          wait(20, msec); // Small delay to prevent excessive updates
      }
      
      // Stop motors once target angle is reached
      LeftDriveSmart.stop();
      RightDriveSmart.stop();
      
      // Drive to the target position
      double distances = sqrt(deltaX * deltaX + deltaY * deltaY); // Calculate distance to target
      prevError = 0;
      integral = 0;
      
      while (fabs(distances) > 1) { // Continue until the robot is close to the target
          error = distances;
          double motorPower = PID(error, prevError, integral, DRIVE_KP, DRIVE_KI, DRIVE_KD); // Compute PID output
          
          // Apply power to drive motors
          LeftDriveSmart.spin(forward, motorPower, percent);
          RightDriveSmart.spin(forward, motorPower, percent);
          
          updateOdometry(); // Update robot position
          
          // Recalculate distance after movement
          distances = sqrt(pow(targetX - robotPos.x, 2) + pow(targetY - robotPos.y, 2));
          wait(20, msec); // Small delay to prevent excessive updates
          printf("X: %.2f Y: %.2f", robotPos.x, robotPos.y);

          if((robotPos.x-1 <= targetX && targetX >= robotPos.x+1) && (robotPos.y-1 <= targetY && targetY >= robotPos.y+1)){
            break;
          }
      }
      
      // Stop motors when the target is reached
      LeftDriveSmart.stop();
      RightDriveSmart.stop();

      printf("X: %.2f Y: %.2f", robotPos.x, robotPos.y);

  }
*/




// collect data for on screen button
typedef struct _button {                               //Like this?
    int    xpos;
    int    ypos;
    int    width;
    int    height;
    bool   state;
    vex::color offColor;
    vex::color onColor;
    const char *labelOff;
    const char *labelOn;
} button;

// Button definitions
button buttons[] = {                                      //what does this array do?
  {   30,  30, 60, 60,  false, 0x000000, 0xff0000, "Red", "Red" },
  {  150,  30, 60, 60,  false, 0x000000, 0x0800ff, "Blue", "Blue" },
  {  270,  30, 60, 60,  false, 0x000000, 0x49e6a7, "Right", "Right" },
  {  390,  30, 60, 60,  false, 0x000000, 0x49e6a7, "Left", "Left" },
  {   30, 150, 60, 60,  false, 0x000000, 0xefc815, "WinPo", "WinPo" },
  {  150, 150, 60, 60,  false, 0x000000, 0xefc815, "WallG", "WallG"},
  {  270, 150, 60, 60,  false, 0x000000, 0xFBDB65, "Elims", "Elims" },
  {  390, 150, 60, 60,  false, 0x000000, 0xfefefe, "Skills", "killMe"}

};

  void displayButtonControls( int index, bool pressed );

  // Check if touch is inside button
  int findButton( int16_t xpos, int16_t ypos ) {
    int nButtons = sizeof(buttons) / sizeof(button);

    for( int index=0;index < nButtons;index++) {
      button *pButton = &buttons[ index ];
      if( xpos < pButton->xpos || xpos > (pButton->xpos + pButton->width) )
        continue;

      if( ypos < pButton->ypos || ypos > (pButton->ypos + pButton->height) )
        continue;

      return(index);
    }
    return (-1);
  }

  // Init button states
  void initButtons() {
    int nButtons = sizeof(buttons) / sizeof(button);

    for( int index=0;index < nButtons;index++) {
      buttons[index].state = false;
    }
  }

  // Screen has been touched 
  void userTouchCallbackPressed() {
    int index;
    int xpos = Brain.Screen.xPosition();
    int ypos = Brain.Screen.yPosition();

    if( (index = findButton( xpos, ypos )) >= 0 ) {
      displayButtonControls( index, true );
    }
  }

  // Screen has been (un)touched
  void userTouchCallbackReleased() {
    int index;
    int xpos = Brain.Screen.xPosition();
    int ypos = Brain.Screen.yPosition();

    if( (index = findButton( xpos, ypos )) >= 0 ) {
      // clear all buttons to false, ie. unselected
      //initButtons(); 

      // now set this one as true
      buttons[index].state = !buttons[index].state;

      displayButtonControls( index, false );
      displayButtonControls( 1,     false );
      displayButtonControls( 2,     false );
      displayButtonControls( 3,     false );
    }
  }

  // Draw all buttons
  void displayButtonControls( int index, bool pressed ) {
    vex::color c;
    Brain.Screen.setPenColor( vex::color(0xFFB6C1) );

    for(int i=0; i<sizeof(buttons)/sizeof(button); i++) {
    //for(button b:buttons) {

      c = buttons[i].state ? buttons[i].onColor : buttons[i].offColor;

      Brain.Screen.setFillColor( c );

      // button fill
      if( i == index && pressed == true )
        Brain.Screen.drawRectangle( buttons[i].xpos, buttons[i].ypos, buttons[i].width, buttons[i].height, c );
      else
        Brain.Screen.drawRectangle( buttons[i].xpos, buttons[i].ypos, buttons[i].width, buttons[i].height );

      // outline
      Brain.Screen.drawRectangle( buttons[i].xpos, buttons[i].ypos, buttons[i].width, buttons[i].height, vex::color::transparent );

      // draw label
      Brain.Screen.setFont(fontType::mono15);
      if(  buttons[i].labelOn != NULL && buttons[i].state)
        Brain.Screen.printAt( buttons[i].xpos + 8, buttons[i].ypos + buttons[i].height - 8, buttons[i].labelOn );
      else if(  buttons[i].labelOff != NULL && !(buttons[i].state))
        Brain.Screen.printAt( buttons[i].xpos + 8, buttons[i].ypos + buttons[i].height - 8, buttons[i].labelOff );
    }
  }


// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {

  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  and_we_and_lift_off.set(false);
  intake_lift.set(false);
  clamp.set(false);
  RightDriveSmart.setStopping(coast);
  LeftDriveSmart.setStopping(coast);
  Drivetrains.setStopping(coast);
  arm.setStopping(coast);
  intake.setStopping(coast);
  armDeg.resetPosition();
  angleTracking.startCalibration();
  // while(angleTracking.isCalibrating()){
  //   task::sleep(5);
  // }
  angleTracking.setHeading(0.0, degrees);

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
void high_goal(){
  armDeg.resetPosition();
  // armDeg.setPosition(5, deg);
  while(armDeg.position(deg)> 250){
    arm.spin(reverse, 120, velocityUnits(volt));
  }

  arm.stop(coast);
}


void ClampDown(){
  clamp.set(true);
}

void ClampUp(){
  clamp.set(false);
}

void DoinkerDown(){
  doinker.set(true);
}

void DoinkerUp(){
  doinker.set(false);
}

void Intake () {
  //   intake.spin(reverse);
  intake.spin(reverse, 80, velocityUnits(volt));
}

void Outake (){
  intake.spin(forward);
}

void Intakestop(){
  intake.stop();
}

//left is false, true is right



void killMeNow(){

 /*          (o_o) Skill Diagram (o_o)          
    ______ ______ _____WG3_____ ______ ______
   |      |      |      |      |      |      |   
   |     BR     BG1     |     BG2     BR     |   
   |__BR_BR______|______G3_____|______BR_BR__|
   |      |      |      |      |      |      |   
   |      |      |      |      |      |      |   
   |_____R15____R16_____|_____R17____R18_____|
   |      |      |      |      |      |      |   
   |      |      |      |      |      |      |   
  WG4_R11_|______|_____R12_____|______|_R13_WG2
   |      |      |      |      |      |      |   
   |      |      |      |      |      |      |   
   |______R7_____R8_____|______R9____R10_____|
   |      |      |      |      |      |      |   
   |      |      |      |      |      |      |   
   |__R3__R4_____G2_____|______G1_____R5__R6_|
   |      |      |      |      |      |      |   
   |      R1     |      |      |      R2     |   
   |______|______|_____WG1_____|______|______| 

   WG = Wall Goal
   G = Mobile Goal
   R = Ring
   ER = Extra Ring
   BG = Blue Ring on Goal 
   BR = Blue Top Stacked Rings

   Skills Plan:
    Leg 1:
      * Start by scoring on WG1
      * Drive diaginally to G1 and grab
      * Score R5 and R6 on G1
      * Place G1 in corner
    Leg 2:
      * Prep arm for WG2
      * Drive to R13 and load into arm
      * Score R13 on WG2
      * Prep arm for WG3
    Leg 3:
      * Drive to R17 and load into arm
      * Drive to BG2 and grab
      * Place BG2 in corner
      * Drive to WG3 and score R17
    Leg 4:
      * Drive to G3 and grab
      * Drive and score two BR on G3
      * PLace G3 in corner
      * (Optional) Drive to R11 and score R11 on WG4
    Leg 5:
      * Drive to R7 and pick up
      * Drive to G2 and grab
      * Score R7 on G2
      * Place G2 in corner
 
 
 */
// setInitialPosition(15, 83.5, 315);
setInitialPosition(100.5, 30, 90);

arm.spinFor(reverse, 0.6, sec, 60, velocityUnits(volt));
moveTo(100.5, 60, 0.003, forward);
ClampDown();
wait(1, sec);
moveTo(100, 40, 0.007, reverse);
intake.spin(reverse, 100, pct);
moveTo(100.5, 30, 0.003, forward);

}


/*          (o_o) Match Diagram (o_o)            
   ______ ______ _____WG3_____ ______ ______
  |      |      |      |      |      |      |   
  |      |      |      RR     |      |      |   
  |______|______|_____BTSR____|______RR_____|
  |      |      |      |      |      |      |   
  |      |      |      |      |      |      |   
  |_____RTSR____G4_____|______G5____RTSR____|
  |      |      |      |      |      |      |   
  |      |      |      |      |      |      |   
 WG4_____|______|______|______|______G2____WG2
  |      |      |      |      |      |      |   
  |      |      |      |      |      |      |   
  |_____BTSR____G3_____|______G1____BTSR____|
  |      |      |      |      |      |      |   
  |      |      |      |      |      |      |   
  |______|______|_____RTSR____|______BR_____|
  |      |      |      |      |      |      |   
  |      |      |      BR     |      |      |   
  |______|______|_____WG1_____|______|______| 
  Red Side

  WG = Wall Goal
  G = Mobile Goal
  BR = Blue Ring
  RR = Red Ring
  BTSR = Blue Top Stacked Rings
  RTSR = Red Top Stacked Rings
*/


// Match Autons

  // Elimanation Autons

    // Red Alliance, Left Side, Elims
    void leftRedElim(){
      Brain.Timer.reset();

    }

    // Red Alliance, Right Side, Elims
    void rightRedElim(){
      Brain.Timer.reset();

    }

    // Blue Alliance, Left Side, Elims
    void leftBlueElim(){
      Brain.Timer.reset();

    }

    // Blue Alliance, Right Side, Elims
    void rightBlueElim(){
      Brain.Timer.reset();

    }

  //

  // Simple Match Autons

    // Red Alliance, Left Side √
    void leftRed(){
      // driveTo(240, 24);
    }

    // Red Alliance, Right Side √
    void rightRed() {
      turnTo(-90, 0.1);
      wait(1,  sec);
      turnTo(90, 0.1);
    }  

    // Blue Alliance, Left Side
    void leftBlue(){
      Brain.Timer.reset();
 

    }

    // Blue Alliance, Right Side
    void rightBlue() {
      Brain.Timer.reset();


    }

  //

  // Alliance Wall Goal Autons

    // Red Alliance, Left Side, Alliance Wall Goal
    void leftRedWallGoal() {
      Brain.Timer.reset();

    }

    // Red Alliance, Right Side, Alliance Wall Goal
    void rightRedWallGoal() {
      Brain.Timer.reset();

    }

    // Blue Alliance, Left Side, Alliance Wall Goal
    void leftBlueWallGoal() {
      Brain.Timer.reset();

    }


    // Red Alliance, Left Side, Alliance Wall Goal
    void rightBlueWallGoal() {
      Brain.Timer.reset();

    }

  //

  // Full Win Point Autons 

    // Red Alliance, Right Side, Full Win Point 
    void rightRedFullWinPoint() {


    }

    void leftRedFullWinPoint() {
      Brain.Timer.reset();

    }

    void rightBlueFullWinPoint() {
      Brain.Timer.reset();
  
    }

    // Blue Alliance, Left Side, Full Win Point 
    void leftBlueFullWinPoint(){
      Brain.Timer.reset();

    }

  //

//

// Auto for mapping drive distance and turn angles for other autos
void positionGettingAuto(){
  trackingR.resetPosition();
  angleTracking.resetRotation();
  double count = 0;
  while(true){
    if(positionButton.value() == 1){
      wait(5, sec);
      printf("Position #%f\nDistance: %f\nAngle: %f\n", count, ((trackingR.position(deg)*3.14)/180), angleTracking.rotation(deg));
      count = count + 1;
      trackingR.resetPosition();
      angleTracking.resetRotation();
    }
  }
}



/*
  void testTracking() {
    while (true) {
      Brain.Screen.clearLine();
      Brain.Screen.print("R: %f, L: %f\n", trackingR.position(degrees), trackingL.position(degrees));
      wait(0.1, seconds);
    }
  }

  void resetTrackingTest() {
    trackingR.resetPosition();
    trackingL.resetPosition();

    wait(0.5, seconds);

    Brain.Screen.print("Tracking R: %f\n", trackingR.position(degrees));
    Brain.Screen.print("Tracking L: %f\n", trackingL.position(degrees));

    wait(2, seconds);
  }

  void test(){
    while(true){
      testTracking();
      resetTrackingTest();
    }
  }

  void wallGoal(){
    billNye(12, forward);
    napoleonDynamite(forward, 44, 3, 50);
    matthewWilder(1, 90, 2, 50);
    detmeritusDmarcus(1, 90, 50, 5);
  }

*/

void autonomous(void) {
  // winPoint();
  // testTracking();
  // test();
  // resetTrackingTest();
  // killMeNow();
  // leftSimple();
  // rightSimple();
  // leftHard();
  // DriveNo(12, inches, 50, forward, 3);
  // leftSimple();
  // rightHard();
   waitUntil(Brain.Timer > 500);
   Brain.Timer.clear();
   
   bool Red       = buttons[0].state;
   bool Blue      = buttons[1].state;
   bool Right     = buttons[2].state;
   bool Left      = buttons[3].state;
   bool WinPoint  = buttons[4].state;
   bool WallGoal  = buttons[5].state;
   bool Elims     = buttons[6].state;
   bool Skills    = buttons[7].state;

   if (Skills) {
    killMeNow();
   } else if (Left && Red &! WinPoint){
      leftRed();
   } else if (Right && Red &! WinPoint) {
      rightRed();
   } else if (Left && Red && WinPoint) {
      leftRedFullWinPoint();
   } else if (Right && Blue &! WinPoint) {
      rightBlue();
   } else if (Left && Blue &! WinPoint) {
      leftBlue();
   } else if (Right && Blue && WinPoint) {
      rightBlueFullWinPoint();
   } else if (Elims && WallGoal) {
      positionGettingAuto();
   }



  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}





/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
bool RemoteControlCodeEnabled = true;
// define variables used for controlling motors based on controller inputs
bool Controller1LeftShoulderControlMotorsStopped = true;
bool Controller1RightShoulderControlMotorsStopped = true;
bool Controller1UpDownButtonsControlMotorsStopped = true;
bool DrivetrainLNeedsToBeStopped_Controller1 = true;
bool DrivetrainRNeedsToBeStopped_Controller1 = true;



double Original_Arm_Position = 0 ; 

double Arm_Set_Position_4_standby = 250  ; 

double Arm_Score_Position = -195 ;

double Arm_Load_Position = -65 ; 

double Arm_Position =0;

double Arm_gap_precision = 6 ; 

double Arm_Set_Postion = 0 ; 



void Controller_Screen_Print () {
   while(true) {

    //Brain.Screen.clearLine();
    Controller1.Screen.clearLine( 1 );
    Controller1.Screen.setCursor( 1, 1 );
    Controller1.Screen.print( Arm_Position) ;
    
    //Controller1.Screen.print("LT: %4.1f RT: %4.10f AT: %4.1f", LeftDriveSmart.temperature(fahrenheit), RightDriveSmart.temperature(fahrenheit), arm.temperature(fahrenheit));
    // wait(0.2, sec);
    Controller1.Screen.clearLine();
    
    Drivetrains.setStopping(coast);
    // int pos1 = inertial1.rotation();
    // int pos2 = inertial1.rotation();
    // int pos3 = inertial1.rotation();

    // int avPos = (pos1 + pos2 + pos3)/3;
    Brain.Screen.print("TL: %4.1f TR: %4.10f TM: %4.1f", LeftDriveSmart.temperature(fahrenheit), RightDriveSmart.temperature(fahrenheit), trackingR.position(deg));
     wait(100, msec);


   }

}

void Intake_Override_senario () {
   intake.spin(fwd, 100, voltageUnits());
  wait(100,msec);
}
bool intakeoverride = false; 
void Skywalker () {


  bool Toggle_Variable = false ; 
  bool Off_Toggle_Variable = false ; 

  bool override_on = false ; 

 while (1==1 ){
   Brain.Screen.clearLine();

    Arm_Position = arm.position(rotationUnits::deg);
   
    ///
    if (Controller1.ButtonR1.pressing() and Controller1.ButtonR2.pressing() and Toggle_Variable == false and Off_Toggle_Variable == false   ){
     
      Toggle_Variable = true ; // set changes
      Arm_Set_Postion = Arm_Load_Position ;  //set likely changes
       override_on = false ; 
      Off_Toggle_Variable = false ;  // same
      Brain.Screen.print("one") ; 

     intakeoverride = false ; 
      

    }
    else if (!Controller1.ButtonR1.pressing() and !Controller1.ButtonR2.pressing() and Toggle_Variable == true and Off_Toggle_Variable == false ){
      override_on = false ; 
      Toggle_Variable = true ;  //same as before
      Arm_Set_Postion = Arm_Load_Position ;  //same as before 
      Off_Toggle_Variable = true ;   //set,  only thing that changes, 
       Brain.Screen.print("two") ; 
        intakeoverride = false ; 
    }
    else if (Controller1.ButtonR1.pressing() and Controller1.ButtonR2.pressing() and Toggle_Variable == true and  Off_Toggle_Variable == true ){
      override_on = false ; 
      thread(Intake_Override_senario).detach();
      wait(60,msec);
      Toggle_Variable = false ;  //changes
      Arm_Set_Postion = Arm_Score_Position ;  //set 
      Off_Toggle_Variable = true ;   //same as before
       Brain.Screen.print("three") ; 
        intakeoverride = true ; 
      

    }
    else if (!Controller1.ButtonR1.pressing() and !Controller1.ButtonR2.pressing() and Toggle_Variable == false and Off_Toggle_Variable == true) {
      override_on = false ; 

      
      Arm_Set_Postion = Arm_Score_Position ;  //same as before 
      Off_Toggle_Variable = false ;   //changes
       Brain.Screen.print("four") ; 
       intakeoverride = false ; 
      Toggle_Variable = false ;  
       Off_Toggle_Variable = false ;
    }


   
    else if (Controller1.ButtonR1.pressing()  and !Controller1.ButtonR2.pressing()) {
      override_on = true ; 
         Brain.Screen.print("five") ; 
        
        arm.spin(reverse, 100, voltageUnits());
      intakeoverride = false ; 
       Toggle_Variable = false ;  
       Off_Toggle_Variable = false ;

    }

    else if (!Controller1.ButtonR1.pressing()  and Controller1.ButtonR2.pressing()) {
      override_on = true ;   
         Brain.Screen.print("six") ; 
       arm.spin(fwd, 100, voltageUnits());


       Toggle_Variable = false ;  
       Off_Toggle_Variable = false ;
       intakeoverride = false ; 
    }

    else if (!Controller1.ButtonR1.pressing()  and !Controller1.ButtonR2.pressing() and override_on == true   ) {
       arm.stop(hold) ;
        Brain.Screen.print("seven") ; 
         intakeoverride = false ; 
    }

    
    if (override_on == false) {

    

      if (Arm_Position < Arm_Set_Postion - Arm_gap_precision ) {
         arm.spin(fwd, 100, voltageUnits());
          Brain.Screen.print(" !1") ; 
           


      }
      else if (Arm_Position > Arm_Set_Postion + Arm_gap_precision ) {
        arm.spin(reverse, 100, voltageUnits());
         Brain.Screen.print(" !2") ; 

        
      }
      else {
        arm.stop(hold) ;
         Brain.Screen.print(" !3") ; 
           
      }

    }

    
 



   wait(10,msec);

 }
  
}


  










void usercontrol() {
 // armDeg.resetPosition();
  // armDeg.setPosition(5, deg);
  // armDeg.setReversed(true);
  // User control code here, inside the loop
  // Brain.Screen.print( "  x: %4.0f   y: %4.0f   z: %4.0f", , launch.position( rev ) );
  RightDriveSmart.setStopping(coast);
  LeftDriveSmart.setStopping(coast);
  Drivetrains.setStopping(coast);
  //arm.setStopping(coast);
  intake.setStopping(coast);
  //arm.setVelocity(11, velocityUnits(volt));
  intake_lift.set(false);

  thread(Controller_Screen_Print).detach(); 
  thread(Skywalker).detach();
  

  //Controller_Screen_Print() ;
  // process the controller input every 20 milliseconds
  // update the motors based on the input values
  while(true) {
    // inertialMain.installed();
    // Drivetrains.setTurnVelocity(40, percent);
    

    // flywheel.setVelocity(83, percent);
    
    if(RemoteControlCodeEnabled) {
      // calculate the drivetrain motor velocities from the controller joystick axies
      // left = Axis3 + Axis1
      // right = Axis3 - Axis18.
      double drivetrainLeftSideSpeed = ((Controller1.Axis3.position() + Controller1.Axis1.position()) /8 ) ;
      double drivetrainRightSideSpeed = ((Controller1.Axis3.position() - Controller1.Axis1.position()) /8 ) ;
    /*
      // //Forward speed with current joystick scaling
      // double Drivespd = Axis3 * (pow(M_E, -d / 10) + pow(M_E, (std::fabs(AxisB) - 100) / 10) * (1 - pow(M_E, -d / 10)));
      // //turn speed (from other joystick) with joystick scaling
      // double Turn = Axis1 * (pow(M_E, (fabs(Axis1) - 100) * t / 1000));

      // leftMotorFront.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorFront.spin(forward, (Drivespd + Turn)*1.27, pct);
      // leftMotorMiddle.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorMiddle.spin(forward, (Drivespd + Turn)*1.27, pct);
      // leftMotorBack.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorBack.spin(forward, (Drivespd + Turn)*1.27, pct);
    */
      // check if the value is inside of the deadband range
      if (drivetrainLeftSideSpeed < 1 && drivetrainLeftSideSpeed > -1) {
        // check if the left motor has already been stopped
        if (DrivetrainLNeedsToBeStopped_Controller1) {
          // stop the left drive motor
          LeftDriveSmart.stop();
          // tell the code that the left motor has been stopped
          DrivetrainLNeedsToBeStopped_Controller1 = false;
        }
      } else {
        // reset the toggle so that the deadband code knows to stop the left motor nexttime the input is in the deadband range
        DrivetrainLNeedsToBeStopped_Controller1 = true;
      }
      // check if the value is inside of the deadband range
      if (drivetrainRightSideSpeed < 1 && drivetrainRightSideSpeed > -1) {
        // check if the right motor has already been stopped
        if (DrivetrainRNeedsToBeStopped_Controller1) {
          // stop the right drive motor
          RightDriveSmart.stop();
          // tell the code that the right motor has been stopped
          DrivetrainRNeedsToBeStopped_Controller1 = false;
        }
      } else {
        // reset the toggle so that the deadband code knows to stop the right motor next time the input is in the deadband range
        DrivetrainRNeedsToBeStopped_Controller1 = true;
      }
      
      // only tell the left drive motor to spin if the values are not in the deadband range
      if (DrivetrainLNeedsToBeStopped_Controller1) {
        // LeftDriveSmart.setVelocity(drivetrainLeftSideSpeed, velocityUnits(volt));
        LeftDriveSmart.spin(forward, drivetrainLeftSideSpeed, voltageUnits(volt));

        // LeftDriveSmart.spin( vex::directionType::rev, 12, vex::voltageUnits::volt);
      }
      // only tell the right drive motor to spin if the values are not in the deadband range
      if (DrivetrainRNeedsToBeStopped_Controller1) {
        // RightDriveSmart.setVelocity(drivetrainRightSideSpeed, velocityUnits(volt));
        RightDriveSmart.spin(forward, drivetrainRightSideSpeed, voltageUnits(volt));
      }
      
      // check the ButtonR1/ButtonR2 status to control Intake
      if(Controller1.ButtonL1.pressing()){
        intake.spin(reverse, 100, voltageUnits(volt));
         intakeoverride = false ; 
      } else if(Controller1.ButtonL2.pressing()){
        intake.spin(forward, 100, voltageUnits(volt));
         intakeoverride = false ; 
      } else if ( intakeoverride == false ) {
        intake.stop();
      }

      Controller1.ButtonX.pressed(ClampDown  );
      Controller1.ButtonA.pressed(ClampUp);
      Controller1.ButtonDown.pressed(DoinkerDown);
      Controller1.ButtonRight.pressed(DoinkerUp);
      
      // Controller1.ButtonLeft.pressed(wingLIn) and ButtonDown).pressed(wingLIn)
      if(Controller1.ButtonY.pressing() and Controller1.ButtonB.pressing() and Controller1.ButtonA.pressing() and Controller1.ButtonX.pressing()){
        and_we_and_lift_off.set(true);
      } else if(Controller1.ButtonUp.pressing()){
        intake_lift.set(true);
      } 

      // Controller1.ButtonA.pressed(high_goal);
      // if(Controller1.ButtonA.pressing()){
      //   arm.spin(forward);
      // } else if( Controller1.ButtonB.pressing()){
      //   arm.spin(reverse);
      // } else{
      //   arm.stop(hold);
      // }
      
    
       


      

      // wait before repeating the process
      wait(10,msec);
      }
        
    }    
    
  }
  // return 1;




// Main will set up the competition functions and callbacks.
//
int main() {
  angleTracking.calibrate();

  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
 // Competition.drivercontrol(usercontrol);
  // Competition.drivercontrol(prints);
  // Run the pre-autonomous function.


  pre_auton();


  // register events for button selection
  Brain.Screen.pressed( userTouchCallbackPressed );
  Brain.Screen.released( userTouchCallbackReleased );

  // make nice background
  Brain.Screen.setFillColor( vex::color(0x000000) ); 
  Brain.Screen.setPenColor ( vex::color(0x000000) ); 
  Brain.Screen.drawRectangle( 0, 0, 480, 120 );

  // initial display
  displayButtonControls( 0, false );

  while(1) {
    Brain.Screen.setFont(fontType::mono20);
    Brain.Screen.setFillColor( vex::color(0x000000) );
    Brain.Screen.setPenColor ( vex::color(0x000000) ); 

    Brain.Screen.setFont(fontType::mono40);
    Brain.Screen.setFillColor( vex::color(0xFFB6C1) );

    Brain.Screen.setPenColor( vex::color(0x000000));
    Brain.Screen.printAt( 0, 135, " Captcha 621A      0.2.0 " );

    this_thread::sleep_for(30);
    Brain.Screen.setPenColor ( vex::color(0x000000) ); 
    wait(20, msec);
  }



  // // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
    
  }
}