/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*
 Pi is a number that never ends
 It goes on and on in twists and bends
 It hides within its digits many mysteries
 Like the shape of circles and the area of spheres 
 It has inspired mathematicians for centuries 
 To explore its patterns and its properties 
 It is more than just a number, it is a symbol 
 Of the beauty and the wonder of the world
*/
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10, 11, 20   
// Controller1          controller                    
// FlyWheel             motor_group   2, 3            
// Intake               motor         9               
// Vision               vision        5               
// Roller               motor         8               
// pneumatics           digital_out   A 
// pneumatics           digital_out   B
// pneumatics           digital_out   C
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include "display-button.h"
#include "autons.h"
#include "functions.h"
competition Competition;
// competition Competition;

using namespace vex;
// collect data for on screen button
typedef struct _button {                               //Like this?
    int    xpos;
    int    ypos;
    int    width;
    int    height;
    bool   state;
    vex::color offColor;
    vex::color onColor;
    const char *labelOff;
    const char *labelOn;
} button;

// Button definitions
button buttons[] = {                                      //what does this array do?
  {   30,  30, 60, 60,  false, 0x000000, 0xCBC3E3, "LSim", "LSim" },
  {  150,  30, 60, 60,  false, 0x000000, 0xCBC3E3, "RSim", "RSim" },
  {  270,  30, 60, 60,  false, 0x000000, 0xCBC3E3, "LHard", "LHard" },
  {  390,  30, 60, 60,  false, 0x000000, 0xCBC3E3, "RHard", "RHard" },
  {   30, 150, 60, 60,  false, 0x000000, 0xCBC3E3, "WinPo", "WinPo" },
  {  150, 150, 60, 60,  false, 0x000000 },
  {  390, 150, 60, 60,  false, 0x000000, 0xCBC3E3, "Skills", "killMe" },
  {  270, 150, 60, 60,  false, 0x000000 }

};

  void displayButtonControls( int index, bool pressed );

  // Check if touch is inside button
  int findButton( int16_t xpos, int16_t ypos ) {
    int nButtons = sizeof(buttons) / sizeof(button);

    for( int index=0;index < nButtons;index++) {
      button *pButton = &buttons[ index ];
      if( xpos < pButton->xpos || xpos > (pButton->xpos + pButton->width) )
        continue;

      if( ypos < pButton->ypos || ypos > (pButton->ypos + pButton->height) )
        continue;

      return(index);
    }
    return (-1);
  }

  // Init button states
  void initButtons() {
    int nButtons = sizeof(buttons) / sizeof(button);

    for( int index=0;index < nButtons;index++) {
      buttons[index].state = false;
    }
  }

  // Screen has been touched 
  void userTouchCallbackPressed() {
    int index;
    int xpos = Brain.Screen.xPosition();
    int ypos = Brain.Screen.yPosition();

    if( (index = findButton( xpos, ypos )) >= 0 ) {
      displayButtonControls( index, true );
    }
  }

  // Screen has been (un)touched
  void userTouchCallbackReleased() {
    int index;
    int xpos = Brain.Screen.xPosition();
    int ypos = Brain.Screen.yPosition();

    if( (index = findButton( xpos, ypos )) >= 0 ) {
      // clear all buttons to false, ie. unselected
      //initButtons(); 

      // now set this one as true
      buttons[index].state = !buttons[index].state;

      displayButtonControls( index, false );
      displayButtonControls( 1,     false );
      displayButtonControls( 2,     false );
      displayButtonControls( 3,     false );
    }
  }

  // Draw all buttons
  void displayButtonControls( int index, bool pressed ) {
    vex::color c;
    Brain.Screen.setPenColor( vex::color(0xFFB6C1) );

    for(int i=0; i<sizeof(buttons)/sizeof(button); i++) {
    //for(button b:buttons) {

      c = buttons[i].state ? buttons[i].onColor : buttons[i].offColor;

      Brain.Screen.setFillColor( c );

      // button fill
      if( i == index && pressed == true )
        Brain.Screen.drawRectangle( buttons[i].xpos, buttons[i].ypos, buttons[i].width, buttons[i].height, c );
      else
        Brain.Screen.drawRectangle( buttons[i].xpos, buttons[i].ypos, buttons[i].width, buttons[i].height );

      // outline
      Brain.Screen.drawRectangle( buttons[i].xpos, buttons[i].ypos, buttons[i].width, buttons[i].height, vex::color::transparent );

      // draw label
      Brain.Screen.setFont(fontType::mono15);
      if(  buttons[i].labelOn != NULL && buttons[i].state)
        Brain.Screen.printAt( buttons[i].xpos + 8, buttons[i].ypos + buttons[i].height - 8, buttons[i].labelOn );
      else if(  buttons[i].labelOff != NULL && !(buttons[i].state))
        Brain.Screen.printAt( buttons[i].xpos + 8, buttons[i].ypos + buttons[i].height - 8, buttons[i].labelOff );
    }
  }


// A global instance of competition


// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!


  Drivetrains.setStopping(coast);
  flywheel.setStopping(coast);
  arm.setStopping(hold);

  intakePistons.set(false);

  wingR.set(false);
  wingL.set(false);

   vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

//Global odom values
double theta{0.0};
double x_pos{0.0};
double y_pos{0.0};

void autonomous(void) {
  // winPoint();
  killMeNow();
  // leftSimple();
  // rightSimple();
  // leftHard();
   waitUntil(Brain.Timer > 1000);
   Brain.Timer.clear();
   
   bool LSimple       = buttons[0].state;
   bool RSimple       = buttons[1].state;
   bool LHard         = buttons[2].state;
   bool RHard         = buttons[3].state;
   bool WinPoint      = buttons[4].state;
   bool skills        = buttons[6].state;

   if (skills) {
    killMeNow();
   } else if (LSimple){
      leftSimple();
   } else if (RSimple) {
      rightSimple();
   } else if (WinPoint) {
      winPoint();
   } else if (RHard) {
      rightHard();
   } else if (LHard) {
      leftHard();
   }
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
  
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

//Remote
/*---------------------------------------------------------------------------*/

bool RemoteControlCodeEnabled = true;
// define variables used for controlling motors based on controller inputs
bool Controller1LeftShoulderControlMotorsStopped = true;
bool Controller1RightShoulderControlMotorsStopped = true;
bool Controller1UpDownButtonsControlMotorsStopped = true;
bool DrivetrainLNeedsToBeStopped_Controller1 = true;
bool DrivetrainRNeedsToBeStopped_Controller1 = true;
/*
void prints() {
  while(true){
    Controller1.Screen.clearLine( 1 );
    Controller1.Screen.setCursor( 1, 1 );
    Controller1.Screen.print("L: %4.1f R: %4.1f D: %4.1f", punch1.temperature(fahrenheit), punch2.temperature(fahrenheit), (RightDriveSmart.temperature(fahrenheit)+LeftDriveSmart.temperature(fahrenheit))/2);

    wait(300, msec);
  }
}
*/

void usercontrol() {
  flywheel.setVelocity(99, velocityUnits(pct));
  arm.setVelocity(90, percentUnits(pct));
  // Firing the match Loads
  // DriveTo(26, inches, 50, reverse);
  Drivetrains.setStopping(brake);





  DriveNoPID(24, inches, 75, forward);
  wait(500, msec);
  Drivetrains.stop(hold);
  // DriveNoPID(35, mm, 7, forward);
  DriveNoPID(4, inches, 20, reverse);
  // intakePistons.set(true);
  wait(50, msec);
  arm.spinFor(reverse, 0.5, rev, 100, velocityUnits(pct), false);
  intakePistons.set(false);
  Drivetrains.stop();
  wait(50, msec);
  // intakePistons.set(false);

  // turnTo(0.25, rev);
  // turnTo(left, 85, deg, 20, velocityUnits(pct));
  flywheel.spin(forward, 500, velocityUnits(rpm));

  LeftDriveSmart.spinFor(-1.74, rev, 10, velocityUnits(pct));
                                                                                
  Drivetrains.stop();

  wingL.set(true);

  DriveTo(6, inches, 50, forward);
  // turnTo(right, 0.125, rev, 75, velocityUnits());

  // wingR.set(true);

  wait(21.4, seconds);


  // Driving to the other side
  // wingR.set(false);
  // DriveTo(9, inches, 26, reverse);
  // // arm.spinFor(forward, 3, sec);
  arm.spinFor(forward, 0.5, rev, 100, velocityUnits(pct), false);
  stopFlywheel();
  wingL.set(false);
  // // User control code here, inside the loop
  // // Brain.Screen.print( "  x: %4.0f   y: %4.0f   z: %4.0f", , launch.position( rev ) );
  // RightDriveSmart.setStopping(coast);
  // LeftDriveSmart.setStopping(coast);
  // Drivetrains.stop(coast);
  // turnTo(right, 43, deg, 10, velocityUnits(pct));

  
  // process the controller input every 20 milliseconds
  // update the motors based on the input values
  while(true) {
    Drivetrains.setStopping(brake);
    // inertialMain.installed();
    // Drivetrains.setTurnVelocity(40, percent);
    Brain.Screen.clearLine();
    Controller1.Screen.clearLine( 1 );
    Controller1.Screen.setCursor( 1, 1 );
    Controller1.Screen.print("F: %4.1f A: %4.1f D: %4.1f", flywheel.temperature(fahrenheit), arm.temperature(fahrenheit), (RightDriveSmart.temperature(fahrenheit)+LeftDriveSmart.temperature(fahrenheit))/2);
    
    // int pos1 = inertial1.rotation();
    // int pos2 = inertial1.rotation();
    // int pos3 = inertial1.rotation();

    // int avPos = (pos1 + pos2 + pos3)/3;
    Brain.Screen.print("T1: %4.1f T2: %4.10f", tracking1.rotation(rev), tracking2.rotation(deg));
    wait(100, msec);

    // flywheel.setVelocity(83, percent);
    intake.setVelocity(100, percent);
    
    if(RemoteControlCodeEnabled) {
      // calculate the drivetrain motor velocities from the controller joystick axies
      // left = Axis3 + Axis1
      // right = Axis3 - Axis1
      int drivetrainLeftSideSpeed = Controller1.Axis3.position() + Controller1.Axis1.position();
      int drivetrainRightSideSpeed = Controller1.Axis3.position() - Controller1.Axis1.position();
      
      // //Forward speed with current joystick scaling
      // double Drivespd = Axis3 * (pow(M_E, -d / 10) + pow(M_E, (std::fabs(AxisB) - 100) / 10) * (1 - pow(M_E, -d / 10)));
      // //turn speed (from other joystick) with joystick scaling
      // double Turn = Axis1 * (pow(M_E, (fabs(Axis1) - 100) * t / 1000));

      // leftMotorFront.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorFront.spin(forward, (Drivespd + Turn)*1.27, pct);
      // leftMotorMiddle.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorMiddle.spin(forward, (Drivespd + Turn)*1.27, pct);
      // leftMotorBack.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorBack.spin(forward, (Drivespd + Turn)*1.27, pct);

      // check if the value is inside of the deadband range
      if (drivetrainLeftSideSpeed < 3 && drivetrainLeftSideSpeed > -15) {
        // check if the left motor has already been stopped
        if (DrivetrainLNeedsToBeStopped_Controller1) {
          // stop the left drive motor
          LeftDriveSmart.stop();
          // tell the code that the left motor has been stopped
          DrivetrainLNeedsToBeStopped_Controller1 = false;
        }
      } else {
        // reset the toggle so that the deadband code knows to stop the left motor nexttime the input is in the deadband range
        DrivetrainLNeedsToBeStopped_Controller1 = true;
      }
      // check if the value is inside of the deadband range
      if (drivetrainRightSideSpeed < 3 && drivetrainRightSideSpeed > -15) {
        // check if the right motor has already been stopped
        if (DrivetrainRNeedsToBeStopped_Controller1) {
          // stop the right drive motor
          RightDriveSmart.stop();
          // tell the code that the right motor has been stopped
          DrivetrainRNeedsToBeStopped_Controller1 = false;
        }
      } else {
        // reset the toggle so that the deadband code knows to stop the right motor next time the input is in the deadband range
        DrivetrainRNeedsToBeStopped_Controller1 = true;
      }
      
      // only tell the left drive motor to spin if the values are not in the deadband range
      if (DrivetrainLNeedsToBeStopped_Controller1) {
        LeftDriveSmart.setVelocity(drivetrainLeftSideSpeed, velocityUnits(volt));
        LeftDriveSmart.spin(forward);

        // LeftDriveSmart.spin( vex::directionType::rev, 12, vex::voltageUnits::volt);
      }
      // only tell the right drive motor to spin if the values are not in the deadband range
      if (DrivetrainRNeedsToBeStopped_Controller1) {
        RightDriveSmart.setVelocity(drivetrainRightSideSpeed, velocityUnits(volt));
        RightDriveSmart.spin(forward);
      }
      
      // check the ButtonR1/ButtonR2 status to control Intake
      if (Controller1.ButtonR1.pressing()) {
        arm.spin(forward, 95, pct);
      } else if (Controller1.ButtonR2.pressing()) {
        arm.spin(reverse, 95, pct);
      } else {
        arm.stop();
      }


      // if the left trigger is pressing, spin the intake forward
      if (Controller1.ButtonL1.pressing()) {
        intakePistons.set(true);  
      } else if(Controller1.ButtonL2.pressing()) {
        intakePistons.set(false);
      } 

      // if( Controller1.ButtonA.pressing()) {
      //    intakePistons.set(true);
      //   } 
      // if( Controller1.ButtonB.pressing()) {
      //    intakePistons.set(false);
      //   }
      Controller1.ButtonX.pressed(spinFlywheel);

      Controller1.ButtonY.pressed(stopFlywheel);

      // Controller1.ButtonL1.pressed(armUp);
      // Controller1.ButtonL2.pressed(armDown);




      Controller1.ButtonRight.pressed(wingROut);
      Controller1.ButtonUp.pressed(wingsOut);
      Controller1.ButtonDown.pressed(wingsIn);
      Controller1.ButtonLeft.pressed(wingLOut);

      Controller1.ButtonA.pressed(speed);
      Controller1.ButtonB.pressed(slow);
      // Controller1.ButtonLeft.pressed(wingLIn) and ButtonDown).pressed(wingLIn)

      
      // wait before repeating the process
      wait(20,msec);
      }
        
    }    
    
  }
  // return 1;




//
// Main will set up the competition functions and callbacks.
//
int main() {
  
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
 // Competition.drivercontrol(usercontrol);
  // Competition.drivercontrol(prints);
  // Run the pre-autonomous function.


 pre_auton();


  // register events for button selection
  Brain.Screen.pressed( userTouchCallbackPressed );
  Brain.Screen.released( userTouchCallbackReleased );

  // make nice background
  Brain.Screen.setFillColor( vex::color(0x000000) ); 
  Brain.Screen.setPenColor ( vex::color(0x000000) ); 
  Brain.Screen.drawRectangle( 0, 0, 480, 120 );

  // initial display
  displayButtonControls( 0, false );

  while(1) {
    Brain.Screen.setFont(fontType::mono20);
    Brain.Screen.setFillColor( vex::color(0x000000) );
    Brain.Screen.setPenColor ( vex::color(0x000000) ); 

    Brain.Screen.setFont(fontType::mono40);
    Brain.Screen.setFillColor( vex::color(0xFFB6C1) );

    Brain.Screen.setPenColor( vex::color(0x000000));
    Brain.Screen.printAt( 0, 135, " Captcha 621A      0.2.0 " );

    this_thread::sleep_for(30);
    Brain.Screen.setPenColor ( vex::color(0x000000) ); 
    wait(20, msec);
  }



  // // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
    
  }
}