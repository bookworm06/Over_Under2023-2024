/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 8, 17, 20    
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

bool RemoteControlCodeEnabled = true;
// define variables used for controlling motors based on controller inputs
bool Controller1LeftShoulderControlMotorsStopped = true;
bool Controller1RightShoulderControlMotorsStopped = true;
bool Controller1UpDownButtonsControlMotorsStopped = true;
bool DrivetrainLNeedsToBeStopped_Controller1 = true;
bool DrivetrainRNeedsToBeStopped_Controller1 = true;
/*
void prints() {
  while(true){
    Controller1.Screen.clearLine( 1 );
    Controller1.Screen.setCursor( 1, 1 );
    Controller1.Screen.print("L: %4.1f R: %4.1f D: %4.1f", punch1.temperature(fahrenheit), punch2.temperature(fahrenheit), (RightDriveSmart.temperature(fahrenheit)+LeftDriveSmart.temperature(fahrenheit))/2);

    wait(300, msec);
  }
}
*/

void usercontrol() {
  // User control code here, inside the loop
  // Brain.Screen.print( "  x: %4.0f   y: %4.0f   z: %4.0f", , launch.position( rev ) );
  RightDriveSmart.setStopping(coast);
  LeftDriveSmart.setStopping(coast);
  Drivetrain.stop(coast);
  
  // process the controller input every 20 milliseconds
  // update the motors based on the input values
  while(true) {
    // inertialMain.installed();
    // Drivetrains.setTurnVelocity(40, percent);

    
    Drivetrain.setStopping(coast);
    // int pos1 = inertial1.rotation();
    // int pos2 = inertial1.rotation();
    // int pos3 = inertial1.rotation();

    // int avPos = (pos1 + pos2 + pos3)/3;
    
    if(RemoteControlCodeEnabled) {
      // calculate the drivetrain motor velocities from the controller joystick axies
      // left = Axis3 + Axis1
      // right = Axis3 - Axis1
      double drivetrainLeftSideSpeed = (Controller1.Axis3.position() + Controller1.Axis1.position() )/ 8.1 ;
      double drivetrainRightSideSpeed = (Controller1.Axis3.position() - Controller1.Axis1.position()) /8.1 ;
      
      // //Forward speed with current joystick scaling
      // double Drivespd = Axis3 * (pow(M_E, -d / 10) + pow(M_E, (std::fabs(AxisB) - 100) / 10) * (1 - pow(M_E, -d / 10)));
      // //turn speed (from other joystick) with joystick scaling
      // double Turn = Axis1 * (pow(M_E, (fabs(Axis1) - 100) * t / 1000));

      // leftMotorFront.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorFront.spin(forward, (Drivespd + Turn)*1.27, pct);
      // leftMotorMiddle.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorMiddle.spin(forward, (Drivespd + Turn)*1.27, pct);
      // leftMotorBack.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorBack.spin(forward, (Drivespd + Turn)*1.27, pct);

      // check if the value is inside of the deadband range
      if (drivetrainLeftSideSpeed < 3 && drivetrainLeftSideSpeed > -3) {
        // check if the left motor has already been stopped
        if (DrivetrainLNeedsToBeStopped_Controller1) {
          // stop the left drive motor
          LeftDriveSmart.stop(coast);
          // tell the code that the left motor has been stopped
          DrivetrainLNeedsToBeStopped_Controller1 = false;
        }
      } else {
        // reset the toggle so that the deadband code knows to stop the left motor nexttime the input is in the deadband range
        DrivetrainLNeedsToBeStopped_Controller1 = true;
      }
      // check if the value is inside of the deadband range
      if (drivetrainRightSideSpeed < 3 && drivetrainRightSideSpeed > -3) {
        // check if the right motor has already been stopped
        if (DrivetrainRNeedsToBeStopped_Controller1) {
          // stop the right drive motor
          RightDriveSmart.stop(coast);
          // tell the code that the right motor has been stopped
          DrivetrainRNeedsToBeStopped_Controller1 = false;
        }
      } else {
        // reset the toggle so that the deadband code knows to stop the right motor next time the input is in the deadband range
        DrivetrainRNeedsToBeStopped_Controller1 = true;
      }
      
      // only tell the left drive motor to spin if the values are not in the deadband range
      if (DrivetrainLNeedsToBeStopped_Controller1) {
        // LeftDriveSmart.setVelocity(drivetrainLeftSideSpeed, velocityUnits(volt));
        LeftDriveSmart.spin(forward, drivetrainLeftSideSpeed, voltageUnits(volt));

        // LeftDriveSmart.spin( vex::directionType::rev, 12, vex::voltageUnits::volt);
      }
      // only tell the right drive motor to spin if the values are not in the deadband range
      if (DrivetrainRNeedsToBeStopped_Controller1) {
        // RightDriveSmart.setVelocity(drivetrainRightSideSpeed, velocityUnits(volt));
        RightDriveSmart.spin(forward, drivetrainRightSideSpeed, voltageUnits(volt));
      }
      
      // check the ButtonR1/ButtonR2 status to control Intake

      // Controller1.ButtonLeft.pressed(wingLIn) and ButtonDown).pressed(wingLIn)

      
      // wait before repeating the process
      wait(20,msec);
      }
        
    }    
    
  }
  // return 1;
 

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
