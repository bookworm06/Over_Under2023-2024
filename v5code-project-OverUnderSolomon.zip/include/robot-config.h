using namespace vex;

extern brain Brain;

using signature = vision::signature;

// VEXcode devices
extern smartdrive Drivetrains;
extern inertial inertial1;
// extern inertial inertial12;
// extern inertial inertial13;
extern motor_group LeftDriveSmart;
extern motor_group RightDriveSmart;
extern motor leftMotorBack;
extern motor rightMotorBack;
extern controller Controller1;
extern motor flywheel;
extern motor arm;
extern motor intake;
extern digital_out intakePistons;
extern digital_out wingR;
extern digital_out wingL;
extern encoder tracking1;
// extern signature Vision__RED_SIDE;
// extern signature Vision__BLUE_SIDE;
extern signature Vision__SIG_3;
extern signature Vision__SIG_4;
extern signature Vision__SIG_5;
extern signature Vision__SIG_6;
extern signature Vision__SIG_7;
// extern vision Vision;
// extern motor Roller;
extern digital_out pneumatics;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );