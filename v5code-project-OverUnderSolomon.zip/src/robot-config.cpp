#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors

//Drive Motors
motor leftMotorFront = motor(PORT1, ratio6_1, false);
motor leftMotorMiddle = motor(PORT13, ratio18_1, true);
motor leftMotorBack = motor(PORT12, ratio6_1, false);
motor_group LeftDriveSmart = motor_group(leftMotorFront, leftMotorMiddle, leftMotorBack);
motor rightMotorFront = motor(PORT10, ratio6_1, true);
motor rightMotorMiddle = motor(PORT18, ratio18_1, false);
motor rightMotorBack = motor(PORT19, ratio6_1, true);
motor_group RightDriveSmart = motor_group(rightMotorFront, rightMotorMiddle, rightMotorBack);

motor arm = motor(PORT11, ratio36_1, false);

motor flywheel = motor(PORT20, ratio6_1, false);

motor intake = motor(PORT2, ratio18_1, true);

digital_out intakePistons = digital_out(Brain.ThreeWirePort.H);

digital_out wingR = digital_out(Brain.ThreeWirePort.C);
digital_out wingL = digital_out(Brain.ThreeWirePort.D);

encoder tracking1 = encoder(Brain.ThreeWirePort.A);

inertial inertial1 = inertial(PORT5);
// inertial inertial12 = inertial(PORT12);
// inertial inertial13 = inertial(PORT14);

smartdrive Drivetrains = smartdrive(LeftDriveSmart, RightDriveSmart, inertial1, 299.24, 276.352, 27.7876, mm, 1);
// drivetrain Drivetrains = drivetrain(LeftDriveSmart, RightDriveSmart,  219.44, 291, 112, mm, 1);
controller Controller1 = controller(primary);




/*vex-vision-config:begin*/
// signature RED_SIDE = signature (1, -3621, -2427, -3024, 8557, 12675, 10616, 3.2, 0);
// signature BLUE_SIDE = signature (2, 7867, 10257, 9062, -2227, -1317, -1772, 3.2, 0);
// vision Vision = vision (PORT5, 50, RED_SIDE, BLUE_SIDE);
/*vex-vision-config:end*/




/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  Brain.Screen.print("Device initialization...");
  Brain.Screen.setCursor(2, 1);
  // calibrate the drivetrain Inertial
  wait(200, msec);
  inertial1.calibrate();
  // inertial12.calibrate();
  // inertial13.calibrate();
  Brain.Screen.print("Calibrating Inertial for Drivetrain");
  // wait for the Inertial calibration process to finish
  while (inertial1.isCalibrating()) {
    wait(25, msec);
  }
  // reset the screen now that the calibration is complete
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1,1);
  wait(50, msec);
  Brain.Screen.clearScreen();
}