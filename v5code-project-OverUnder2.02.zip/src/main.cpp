/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*
 Pi is a number that never ends
 It goes on and on in twists and bends
 It hides within its digits many mysteries
 Like the shape of circles and the area of spheres 
 It has inspired mathematicians for centuries 
 To explore its patterns and its properties 
 It is more than just a number, it is a symbol 
 Of the beauty and the wonder of the world
*/
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10, 11, 20   
// Controller1          controller                    
// FlyWheel             motor_group   2, 3            
// Intake               motor         9               
// Vision               vision        5               
// Roller               motor         8               
// pneumatics           digital_out   A 
// pneumatics           digital_out   B
// pneumatics           digital_out   C
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include "display-button.h"
#include "autons.h"
#include "functions.h"

// competition Competition;

using namespace vex;
// collect data for on screen button
typedef struct _button {                               //Like this?
    int    xpos;
    int    ypos;
    int    width;
    int    height;
    bool   state;
    vex::color offColor;
    vex::color onColor;
    const char *labelOff;
    const char *labelOn;
} button;

// Button definitions
button buttons[] = {                                      //what does this array do?
  {   30,  30, 60, 60,  false, 0xCBC3E3, 0xFFB6C1, "LSimple", "LSimple" },
  {  150,  30, 60, 60,  false, 0xCBC3E3, 0xFFB6C1, "RSimple", "RSimple" },
  {  270,  30, 60, 60,  false, 0xCBC3E3, 0xFFB6C1, "WinPoint", "WinPoint" },
  {  390,  30, 60, 60,  false, 0xCBC3E3, 0xFFB6C1, "RHard", "RHard" },
  {   30, 150, 60, 60,  false, 0xCBC3E3 },
  {  150, 150, 60, 60,  false, 0xCBC3E3 },
  {  390, 150, 60, 60,  false, 0xCBC3E3, 0xFFB6C1, "Skills", "killMe" },
  {  270, 150, 60, 60,  false, 0xCBC3E3 }

};

  void displayButtonControls( int index, bool pressed );

  // Check if touch is inside button
  int findButton( int16_t xpos, int16_t ypos ) {
    int nButtons = sizeof(buttons) / sizeof(button);

    for( int index=0;index < nButtons;index++) {
      button *pButton = &buttons[ index ];
      if( xpos < pButton->xpos || xpos > (pButton->xpos + pButton->width) )
        continue;

      if( ypos < pButton->ypos || ypos > (pButton->ypos + pButton->height) )
        continue;

      return(index);
    }
    return (-1);
  }

  // Init button states
  void initButtons() {
    int nButtons = sizeof(buttons) / sizeof(button);

    for( int index=0;index < nButtons;index++) {
      buttons[index].state = false;
    }
  }

  // Screen has been touched 
  void userTouchCallbackPressed() {
    int index;
    int xpos = Brain.Screen.xPosition();
    int ypos = Brain.Screen.yPosition();

    if( (index = findButton( xpos, ypos )) >= 0 ) {
      displayButtonControls( index, true );
    }
  }

  // Screen has been (un)touched
  void userTouchCallbackReleased() {
    int index;
    int xpos = Brain.Screen.xPosition();
    int ypos = Brain.Screen.yPosition();

    if( (index = findButton( xpos, ypos )) >= 0 ) {
      // clear all buttons to false, ie. unselected
      //initButtons(); 

      // now set this one as true
      buttons[index].state = !buttons[index].state;

      displayButtonControls( index, false );
      displayButtonControls( 1,     false );
      displayButtonControls( 2,     false );
      displayButtonControls( 3,     false );
    }
  }

  // Draw all buttons
  void displayButtonControls( int index, bool pressed ) {
    vex::color c;
    Brain.Screen.setPenColor( vex::color(0xFFB6C1) );

    for(int i=0; i<sizeof(buttons)/sizeof(button); i++) {
    //for(button b:buttons) {

      c = buttons[i].state ? buttons[i].onColor : buttons[i].offColor;

      Brain.Screen.setFillColor( c );

      // button fill
      if( i == index && pressed == true )
        Brain.Screen.drawRectangle( buttons[i].xpos, buttons[i].ypos, buttons[i].width, buttons[i].height, c );
      else
        Brain.Screen.drawRectangle( buttons[i].xpos, buttons[i].ypos, buttons[i].width, buttons[i].height );

      // outline
      Brain.Screen.drawRectangle( buttons[i].xpos, buttons[i].ypos, buttons[i].width, buttons[i].height, vex::color::transparent );

      // draw label
      Brain.Screen.setFont(fontType::mono15);
      if(  buttons[i].labelOn != NULL && buttons[i].state)
        Brain.Screen.printAt( buttons[i].xpos + 8, buttons[i].ypos + buttons[i].height - 8, buttons[i].labelOn );
      else if(  buttons[i].labelOff != NULL && !(buttons[i].state))
        Brain.Screen.printAt( buttons[i].xpos + 8, buttons[i].ypos + buttons[i].height - 8, buttons[i].labelOff );
    }
  }


// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  Drivetrain.setStopping(coast);
  punch1.setStopping(coast);
  punch2.setStopping(coast);

  leftWing.set(false);
  rightWing.set(false);

  rightHook.set(true);
  leftHook.set(true);
  

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

//Global odom values
double theta{0.0};
double x_pos{0.0};
double y_pos{0.0};

void autonomous(void) {
   waitUntil(Brain.Timer > 1000);
   Brain.Timer.clear();
   
   bool LSimple       = buttons[0].state;
   bool RSimple       = buttons[1].state;
   bool WinPoint      = buttons[2].state;
   bool RHard         = buttons[3].state;
   bool skills        = buttons[6].state;

   if (skills) {
    killMeNow();
   } else if (LSimple){
      leftSimple();
   } else if (RSimple) {
      rightSimple();
   } else if (WinPoint) {
      winPoint();
   } else if (RHard) {
      rightHard();
   }
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
  
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

//Remote
/*---------------------------------------------------------------------------*/

bool RemoteControlCodeEnabled = true;
// define variables used for controlling motors based on controller inputs
bool Controller1LeftShoulderControlMotorsStopped = true;
bool Controller1RightShoulderControlMotorsStopped = true;
bool Controller1UpDownButtonsControlMotorsStopped = true;
bool DrivetrainLNeedsToBeStopped_Controller1 = true;
bool DrivetrainRNeedsToBeStopped_Controller1 = true;


void usercontrol() {
  // User control code here, inside the loop
  RightDriveSmart.setStopping(coast);
  LeftDriveSmart.setStopping(coast);
  
  // process the controller input every 20 milliseconds
  // update the motors based on the input values
  while(true) {
    Drivetrain.setTurnVelocity(90, pct);
    punch1.setVelocity(100, percent);
    punch2.setVelocity(100, percent);
    if(RemoteControlCodeEnabled) {
      // calculate the drivetrain motor velocities from the controller joystick axies
      // left = Axis3 + Axis1
      // right = Axis3 - Axis1
      int drivetrainLeftSideSpeed = Controller1.Axis3.position() + Controller1.Axis1.position();
      int drivetrainRightSideSpeed = Controller1.Axis3.position() - Controller1.Axis1.position();
      
      // //Forward speed with current joystick scaling
      // double Drivespd = Axis3 * (pow(M_E, -d / 10) + pow(M_E, (std::fabs(AxisB) - 100) / 10) * (1 - pow(M_E, -d / 10)));
      // //turn speed (from other joystick) with joystick scaling
      // double Turn = Axis1 * (pow(M_E, (std::fabs(AxisA) - 100) * t / 1000));

      // leftMotorA.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorA.spin(forward, (Drivespd + Turn)*1.27, pct);
      // leftMotorB.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorB.spin(forward, (Drivespd + Turn)*1.27, pct);
      // leftMotorC.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorC.spin(forward, (Drivespd + Turn)*1.27, pct);

      // check if the value is inside of the deadband range
      if (drivetrainLeftSideSpeed < 5 && drivetrainLeftSideSpeed > -5) {
        // check if the left motor has already been stopped
        if (DrivetrainLNeedsToBeStopped_Controller1) {
          // stop the left drive motor
          LeftDriveSmart.stop();
          // tell the code that the left motor has been stopped
          DrivetrainLNeedsToBeStopped_Controller1 = false;
        }
      } else {
        // reset the toggle so that the deadband code knows to stop the left motor nexttime the input is in the deadband range
        DrivetrainLNeedsToBeStopped_Controller1 = true;
      }
      // check if the value is inside of the deadband range
      if (drivetrainRightSideSpeed < 5 && drivetrainRightSideSpeed > -5) {
        // check if the right motor has already been stopped
        if (DrivetrainRNeedsToBeStopped_Controller1) {
          // stop the right drive motor
          RightDriveSmart.stop();
          // tell the code that the right motor has been stopped
          DrivetrainRNeedsToBeStopped_Controller1 = false;
        }
      } else {
        // reset the toggle so that the deadband code knows to stop the right motor next time the input is in the deadband range
        DrivetrainRNeedsToBeStopped_Controller1 = true;
      }
      
      // only tell the left drive motor to spin if the values are not in the deadband range
      if (DrivetrainLNeedsToBeStopped_Controller1) {
        LeftDriveSmart.setVelocity(drivetrainLeftSideSpeed, percent);
        LeftDriveSmart.spin(forward);

        // LeftDriveSmart.spin( vex::directionType::rev, 12, vex::voltageUnits::volt);
      }
      // only tell the right drive motor to spin if the values are not in the deadband range
      if (DrivetrainRNeedsToBeStopped_Controller1) {
        RightDriveSmart.setVelocity(drivetrainRightSideSpeed, percent);
        RightDriveSmart.spin(forward);
      }
      
      // check the ButtonR1/ButtonR2 status to control Intake
      if (Controller1.ButtonR1.pressing()) {
        rightHook.set(true);
        leftHook.set(true);
      } else if (Controller1.ButtonR2.pressing()) {
        rightHook.set(true);
        leftHook.set(true);
      }
      // wait before repeating the process
      // wait(20, msec);
        //If button up pressed, activate
        if( Controller1.ButtonY.pressing()) {
          
        }
        //Otherwise don’t activate
        else {
          
        }
      wait(20,msec);

        if( fire.value() == true ) {
         // Brain.Screen.print("true");
         launch.spinFor(forward, 650.4, degrees);
        } else if ( fire.value() == false) {
           launch.stop();
        }

        if( Controller1.ButtonA.pressing()) {
         rightWing.set(true);
         leftWing.set(true);
        } 
        if( Controller1.ButtonB.pressing()) {
         leftWing.set(false);
         rightWing.set(false);
        }
      }
        
    }    
    
  }
  // return 1;




//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // register events for button selection
  Brain.Screen.pressed( userTouchCallbackPressed );
  Brain.Screen.released( userTouchCallbackReleased );

  // make nice background
  Brain.Screen.setFillColor( vex::color(0x000000) ); 
  Brain.Screen.setPenColor ( vex::color(0x000000) ); 
  Brain.Screen.drawRectangle( 0, 0, 480, 120 );

  // initial display
  displayButtonControls( 0, false );

  while(1) {
    Brain.Screen.setFont(fontType::mono20);
    Brain.Screen.setFillColor( vex::color(0x000000) );
    Brain.Screen.setPenColor ( vex::color(0x000000) ); 

    Brain.Screen.setFont(fontType::mono40);
    Brain.Screen.setFillColor( vex::color(0xFFB6C1) );

    Brain.Screen.setPenColor( vex::color(0x000000));
    Brain.Screen.printAt( 0, 135, " Captcha 621A      0.2.0 " );

    this_thread::sleep_for(30);
    Brain.Screen.setPenColor ( vex::color(0x000000) ); 

  }
  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
    
  }
}