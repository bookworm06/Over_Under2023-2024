#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor leftMotorFront = motor(PORT10, ratio6_1, false);
        // motor leftMotorMiddle = motor(PORT19, ratio18_1, true);
motor leftMotorBack = motor(PORT1, ratio6_1, false);
motor_group LeftDriveSmart = motor_group(leftMotorFront, leftMotorBack);
motor rightMotorFront = motor(PORT20, ratio6_1, true);
        // motor rightMotorMiddle = motor(PORT9, ratio18_1, false);
motor rightMotorBack = motor(PORT11, ratio6_1, true);
motor_group RightDriveSmart = motor_group(rightMotorFront, rightMotorBack);

motor punch1 = motor(PORT3, ratio18_1, true);
motor punch2 = motor(PORT2, ratio18_1, true);

motor_group launch = motor_group(punch1, punch2);

digital_out leftWing = digital_out(Brain.ThreeWirePort.A);
digital_out rightWing = digital_out(Brain.ThreeWirePort.H);

digital_out leftHook = digital_out(Brain.ThreeWirePort.F);
digital_out rightHook = digital_out(Brain.ThreeWirePort.G);

limit fire = limit(Brain.ThreeWirePort.B);

inertial DrivetrainInertial = inertial(PORT13);
// smartdrive Drivetrain = smartdrive(LeftDriveSmart, RightDriveSmart, DrivetrainInertial, 299.24, 393.7, 35, mm, 0.3333333333333333);
drivetrain Drivetrain = drivetrain(LeftDriveSmart, RightDriveSmart,  219.44, 291, 112, mm, 1);
controller Controller1 = controller(primary);




/*vex-vision-config:begin*/
// signature RED_SIDE = signature (1, -3621, -2427, -3024, 8557, 12675, 10616, 3.2, 0);
// signature BLUE_SIDE = signature (2, 7867, 10257, 9062, -2227, -1317, -1772, 3.2, 0);
// vision Vision = vision (PORT5, 50, RED_SIDE, BLUE_SIDE);
/*vex-vision-config:end*/




/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  Brain.Screen.print("Device initialization...");
  Brain.Screen.setCursor(2, 1);
  // calibrate the drivetrain Inertial
  wait(200, msec);
  DrivetrainInertial.calibrate();
  Brain.Screen.print("Calibrating Inertial for Drivetrain");
  // wait for the Inertial calibration process to finish
  while (DrivetrainInertial.isCalibrating()) {
    wait(25, msec);
  }
  // reset the screen now that the calibration is complete
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1,1);
  wait(50, msec);
  Brain.Screen.clearScreen();
}