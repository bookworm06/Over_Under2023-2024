/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <algorithm>

using namespace vex;

/*
 Pi is a number that never ends
 It goes on and on in twists and bends
 It hides within its digits many mysteries
 Like the shape of circles and the area of spheres 
 It has inspired mathematicians for centuries 
 To explore its patterns and its properties 
 It is more than just a number, it is a symbol 
 Of the beauty and the wonder of the world
*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    20, 18, 17, 10, 3, 4   
// Controller1          controller                    
// Arm                  motor         19            
// Intake               motor         16                                            
// pneumatics           digital_out   A 
// pneumatics           digital_out   H
// ---- END VEXCODE CONFIGURED DEVICES ----


///////////////////////////////////////
//global varible definition section
///////////////////////////////////////
 float Kp = 0.5;  // Proportional constant
 float Ki = 0.1;  // Integral constant
 float Kd = 0.2;  // Derivative constant
 // float targetDistance = 1000;  // Target distance in inches (or degrees)
 // float targetAngle = 90;  // Target angle in degrees
 
 // Define tolerance and deltaTime
 float tolerance = 1.0;  // Error tolerance in distance or angle
 float deltaTime = 0.02;  // Time step for PID calculations (in seconds)
 
 // Variables for PID calculations
 float error = 0;
 float integral = 0;
 float derivative = 0;
 float prevError = 0;
 float currentPosition = 0;
 float currentAngle = 0;
 float powerValue = 0;
 float driveDirection = 1;  // 1 for forward, -1 for backward
 float turnDirection = 1;   // 1 for clockwise, -1 for counterclockwise
 double wheelBase = 6;
 double tire_diamiter = 2;
//

void DriveNo(double dist, distanceUnits units, double speed, directionType dir, double drivetimer) {
    trackingL.setReversed(false);
    trackingR.setReversed(true);
    // Reset tracking wheels
    trackingL.resetPosition();
    trackingR.resetPosition();
    trackingM.resetPosition();

    // Convert distance to target encoder counts
    double targetPosition; 
    double wheelCircumference = tire_diamiter * M_PI;  // Calculate wheel circumference
    
    if (units == distanceUnits::in) {
        targetPosition = (dist / wheelCircumference) * 360;  // Inches to degrees
    } else if (units == distanceUnits::cm) {
        targetPosition = (dist / wheelCircumference) * 360;  // CM to degrees
    } else {
        targetPosition = dist;  // Assume it's already in degrees
    }

    // Initialize timer for timeout
    double starttime = Brain.Timer.value();

    // Start driving in the specified direction
    Drivetrains.setDriveVelocity(speed, velocityUnits::pct);
    if (dir == directionType::fwd) {
        Drivetrains.drive(forward);
    } else {
        Drivetrains.drive(reverse);
    }

    while (true) {
        // Calculate the average position of the tracking wheels
        double pos1 = trackingR.position(rotationUnits::deg);
        double pos2 = trackingR.position(rotationUnits::deg);
        double avgPosition = (pos1 + pos2) / 2.0;

        // Stop if target distance is reached
        if (fabs(avgPosition) >= targetPosition) {
            break;
        }

        // Timeout condition
        if ((Brain.Timer.value() - starttime) >= drivetimer) {
            Controller1.Screen.print("Timeout");
            break;
        }

        // Delay to prevent CPU overload
        wait(20, msec);
    }

    // Stop the drivetrain
    Drivetrains.stop(brakeType::hold);
}

//void trackingM distance (double targetDistance,directionType){ directionType = 1 trackingM rotation)};

// Function to drive the robot based on PID control

//void trackingM; distance = trackingM rotation);

void drivePID(double targetDistance, directionType direc) {

   // while(fabs(targetDistance-currentPosition)>tolerance){currentPosition= (drivetrain distance);

  while (fabs(targetDistance - currentPosition) > tolerance) {
      currentPosition = (trackingR.position(degrees) + trackingR.position(degrees)) / 2;

      error = targetDistance - currentPosition;
      integral += error * deltaTime;
      derivative = (error - prevError) / deltaTime;
      powerValue = Kp * error + Ki * integral + Kd * derivative;

      if( error <= tolerance){
        break;
      }

      // Apply power to the motors directly based on direction
      // RightDriveSmart.setVelocity(driveDirection * powerValue, percent);
      // LeftDriveSmart.setVelocity(driveDirection * powerValue, percent);
      // RightDriveSmart.spin(forward);  // Assuming forward means driving forward
      // LeftDriveSmart.spin(forward);

      Drivetrains.setDriveVelocity(turnDirection * powerValue, percent);
      Drivetrains.drive(direc);  // Use directionType for driving (e.g., forward, reverse)

      prevError = error;

      wait(20, msec); // Loop delay to ensure smooth PID control
  }
 // drivetrain.stop();
}

// Function to turn the robot based on PID control
void turnPID(float targetAngle, turnType direc) {

  while (fabs(targetAngle - currentAngle) > tolerance) {
      currentAngle = (trackingR.position(degrees) - trackingL.position(degrees)) / wheelBase;

      error = targetAngle - currentAngle;
      integral += error * deltaTime;
      derivative = (error - prevError) / deltaTime;
      powerValue = Kp * error + Ki * integral + Kd * derivative;

      if( error <= tolerance){
        break;
      }

      // Apply differential power to motors based on the turn direction
      // RightDriveSmart.setVelocity(turnDirection * -powerValue, percent);
      // LeftDriveSmart.setVelocity(turnDirection * powerValue, percent);
      // LeftDriveSmart.spin(forward);
      // RightDriveSmart.spin(forward);

      Drivetrains.setTurnVelocity(turnDirection * powerValue, percent);
      Drivetrains.turn(direc);  // Use turnType for turning (e.g., left, right)

      prevError = error;

      wait(20, msec); // Loop delay for smooth turning
  }
  Drivetrains.stop();
}


void function(directionType dir, int dist, int speed) {
  Drivetrains.driveFor(dir, dist, inches, speed, velocityUnits(pct));
}

double normalizeAngle(double angle) {
    while (angle >= 360) angle -= 360;
    while (angle < 0) angle += 360;
    return angle;
}

// collect data for on screen button
typedef struct _button {                               //Like this?
    int    xpos;
    int    ypos;
    int    width;
    int    height;
    bool   state;
    vex::color offColor;
    vex::color onColor;
    const char *labelOff;
    const char *labelOn;
} button;

// Button definitions
button buttons[] = {                                      //what does this array do?
  {   30,  30, 60, 60,  false, 0x000000, 0xCBC3E3, "LRed", "LRed" },
  {  150,  30, 60, 60,  false, 0x000000, 0xCBC3E3, "RRed", "RRed" },
  {  270,  30, 60, 60,  false, 0x000000, 0xCBC3E3, "LBlue", "LBlue" },
  {  390,  30, 60, 60,  false, 0x000000, 0xCBC3E3, "RBlue", "RBlue" },
  {   30, 150, 60, 60,  false, 0x000000, 0xCBC3E3, "WinPo", "WinPo" },
  {  150, 150, 60, 60,  false, 0x000000, 0xCBC3E3, "Funny", "Funny"},
  {  390, 150, 60, 60,  false, 0x000000, 0xCBC3E3, "Skills", "killMe" },
  {  270, 150, 60, 60,  false, 0x000000 }

};

  void displayButtonControls( int index, bool pressed );

  // Check if touch is inside button
  int findButton( int16_t xpos, int16_t ypos ) {
    int nButtons = sizeof(buttons) / sizeof(button);

    for( int index=0;index < nButtons;index++) {
      button *pButton = &buttons[ index ];
      if( xpos < pButton->xpos || xpos > (pButton->xpos + pButton->width) )
        continue;

      if( ypos < pButton->ypos || ypos > (pButton->ypos + pButton->height) )
        continue;

      return(index);
    }
    return (-1);
  }

  // Init button states
  void initButtons() {
    int nButtons = sizeof(buttons) / sizeof(button);

    for( int index=0;index < nButtons;index++) {
      buttons[index].state = false;
    }
  }

  // Screen has been touched 
  void userTouchCallbackPressed() {
    int index;
    int xpos = Brain.Screen.xPosition();
    int ypos = Brain.Screen.yPosition();

    if( (index = findButton( xpos, ypos )) >= 0 ) {
      displayButtonControls( index, true );
    }
  }

  // Screen has been (un)touched
  void userTouchCallbackReleased() {
    int index;
    int xpos = Brain.Screen.xPosition();
    int ypos = Brain.Screen.yPosition();

    if( (index = findButton( xpos, ypos )) >= 0 ) {
      // clear all buttons to false, ie. unselected
      //initButtons(); 

      // now set this one as true
      buttons[index].state = !buttons[index].state;

      displayButtonControls( index, false );
      displayButtonControls( 1,     false );
      displayButtonControls( 2,     false );
      displayButtonControls( 3,     false );
    }
  }

  // Draw all buttons
  void displayButtonControls( int index, bool pressed ) {
    vex::color c;
    Brain.Screen.setPenColor( vex::color(0xFFB6C1) );

    for(int i=0; i<sizeof(buttons)/sizeof(button); i++) {
    //for(button b:buttons) {

      c = buttons[i].state ? buttons[i].onColor : buttons[i].offColor;

      Brain.Screen.setFillColor( c );

      // button fill
      if( i == index && pressed == true )
        Brain.Screen.drawRectangle( buttons[i].xpos, buttons[i].ypos, buttons[i].width, buttons[i].height, c );
      else
        Brain.Screen.drawRectangle( buttons[i].xpos, buttons[i].ypos, buttons[i].width, buttons[i].height );

      // outline
      Brain.Screen.drawRectangle( buttons[i].xpos, buttons[i].ypos, buttons[i].width, buttons[i].height, vex::color::transparent );

      // draw label
      Brain.Screen.setFont(fontType::mono15);
      if(  buttons[i].labelOn != NULL && buttons[i].state)
        Brain.Screen.printAt( buttons[i].xpos + 8, buttons[i].ypos + buttons[i].height - 8, buttons[i].labelOn );
      else if(  buttons[i].labelOff != NULL && !(buttons[i].state))
        Brain.Screen.printAt( buttons[i].xpos + 8, buttons[i].ypos + buttons[i].height - 8, buttons[i].labelOff );
    }
  }


// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  and_we_and_lift_off.set(false);
  clamp.set(false);
  RightDriveSmart.setStopping(coast);
  LeftDriveSmart.setStopping(coast);
  Drivetrains.setStopping(coast);
  arm.setStopping(coast);
  intake.setStopping(coast);
  armDeg.resetPosition();


  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/


  //left is false, true is right


//int Drivetrains.turnFor (); ????

void ClampDown(){
  clamp.set(true);
}

void ClampUp(){
  clamp.set(false);
}

void DoinkerDown(){
  doinker.set(true);
}

void DoinkerUp(){
  doinker.set(false);
}

void Intake () {
//   intake.spin(reverse);
  intake.spin(reverse, 80, velocityUnits(volt));
}

void Outake (){
  intake.spin(forward);
}

void Intakestop(){
  intake.stop();
}

//void high_goal(){


void killMeNow(){

 /*          (o_o) Skill Diagram (o_o)          
    ______ ______ _____WG3_____ ______ ______
   |      |      |      |      |      |      |   
   |      |      |      |      |      |      |   
   |______|______|______|______|______|______|
   |      |      |      |      |      |      |   
   |      |      |      |      |      |      |   
   |______|______|______|______|______|______|
   |      |      |      |      |      |      |   
   |      |      |      |      |      |      |   
  WG4_____|______|______|______|______|_____WG2
   |      |      |      |      |      |      |   
   |      |      |      |      |      |      |   
   |______R6_____R5_____|______R1_____R2_____|
   |      |      |      |      |      |      |   
   |      |      |      |      |      |      |   
   |__ER__R7_____G2_____|______G1_____R3__ER_|
   |      |      |      |      |      |      |   
   |      R8     |      |      |      R4     |   
   |______|______|_____WG1_____|______|______| 

   WG = Wall Goal
   G = Mobile Goal
   R = Ring
   ER = Extra Ring

 */



}


/*          (o_o) Match Diagram (o_o)            
   ______ ______ _____WG3_____ ______ ______
  |      |      |      |      |      |      |   
  |      |      |      RR     |      |      |   
  |______|______|_____BTSR____|______RR_____|
  |      |      |      |      |      |      |   
  |      |      |      |      |      |      |   
  |_____RTSR____G4_____|______G5____RTSR____|
  |      |      |      |      |      |      |   
  |      |      |      |      |      |      |   
 WG4_____|______|______|______|______G2____WG2
  |      |      |      |      |      |      |   
  |      |      |      |      |      |      |   
  |_____BTSR____G3_____|______G1____BTSR____|
  |      |      |      |      |      |      |   
  |      |      |      |      |      |      |   
  |______|______|_____RTSR____|______BR_____|
  |      |      |      |      |      |      |   
  |      |      |      BR     |      |      |   
  |______|______|_____WG1_____|______|______| 
  Red Side

  WG = Wall Goal
  G = Mobile Goal
  BR = Blue Ring
  RR = Red Ring
  BTSR = Blue Top Stacked Rings
  RTSR = Red Top Stacked Rings
*/

void leftRed(){

  DriveNo(3, inches, 50, reverse, 1);
  wait(0.5, sec);
  ClampDown();
  wait(0.5,sec);
  Intake();
  wait(2,sec);
  Intakestop();
 // turnPID(2, left);
  Drivetrains.turnFor (right, 20, degrees, 60, velocityUnits());
  DriveNo (4, inches, 50, reverse, 0.5);



}

void rightRed() {

  DriveNo(3, inches, 55, reverse, 1);
  ClampDown();
  wait(0.5, sec);
  DriveNo(2, inches, 40, forward, 1);
  Intake();
  wait(0.5, sec);
  Intakestop();
  
  Drivetrains.turnFor (left, 10, degrees);

  
  

}

void leftBlue(){

}

void rightBlue() {

}

void winPoint(){

}



void testTracking() {
  while (true) {
    Brain.Screen.clearLine();
    Brain.Screen.print("R: %f, L: %f\n", trackingR.position(degrees), trackingL.position(degrees));
    wait(0.1, seconds);
  }
}

void resetTrackingTest() {
  trackingR.resetPosition();
  trackingL.resetPosition();

  wait(0.5, seconds);

  Brain.Screen.print("Tracking R: %f\n", trackingR.position(degrees));
  Brain.Screen.print("Tracking L: %f\n", trackingL.position(degrees));

  wait(2, seconds);
}

void test(){
  while(true){
    testTracking();
    resetTrackingTest();
  }
}

void autonomous(void) {
  // winPoint();
  // testTracking();
  // test();
  // resetTrackingTest();
  //killMeNow();
  // leftSimple();
  // rightSimple();
  // leftHard();
  //DriveNo(12, inches, 50, forward, 3);
  // leftSimple();
  // rightHard();
   waitUntil(Brain.Timer > 1000);
   Brain.Timer.clear();
   
   bool LeftRed       = buttons[0].state;
   bool RightRed      = buttons[1].state;
   bool LeftBlue      = buttons[2].state;
   bool RightBlue     = buttons[3].state;
   bool WinPoint      = buttons[4].state;
   bool Skills        = buttons[6].state;

   if (Skills) {
    killMeNow();
   } else if (LeftRed){
      leftRed();
   } else if (RightRed) {
      rightRed();
   } else if (WinPoint) {
      winPoint();
   } else if (RightBlue) {
      rightBlue();
   } else if (LeftBlue) {
      leftBlue();
   }



  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}

//void ClampDown(){
  //clamp.set(true);
//}

//void ClampUp(){
//  clamp.set(false);
//}

//void DoinkerDown(){
//  doinker.set(true);
//}

//void DoinkerUp(){
//  doinker.set(false);
//}

void high_goal(){
  armDeg.resetPosition();
  // armDeg.setPosition(5, deg);
  while(armDeg.position(deg)> 340){
    arm.spin(forward, 50, velocityUnits(volt));
  }
  arm.stop(hold);
  intake.spinFor(reverse, 3, sec);
  while(armDeg.position(deg)> 250){
    arm.spin(forward, 120, velocityUnits(volt));
  }
  wait(0.5, sec);
  while(armDeg.position(deg)< 355){
    arm.spin(reverse, 120, velocityUnits(volt));
  }
  arm.stop(coast);
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
bool RemoteControlCodeEnabled = true;
// define variables used for controlling motors based on controller inputs
bool Controller1LeftShoulderControlMotorsStopped = true;
bool Controller1RightShoulderControlMotorsStopped = true;
bool Controller1UpDownButtonsControlMotorsStopped = true;
bool DrivetrainLNeedsToBeStopped_Controller1 = true;
bool DrivetrainRNeedsToBeStopped_Controller1 = true;



double Original_Arm_Position = 0 ; 

double Arm_Set_Position_4_standby = 250  ; 

double Arm_Score_Position = -195 ;

double Arm_Load_Position = -65 ; 

double Arm_Position =0;

double Arm_gap_precision = 6 ; 

double Arm_Set_Postion = 0 ; 



void Controller_Screen_Print () {
   while(true) {

    //Brain.Screen.clearLine();
    Controller1.Screen.clearLine( 1 );
    Controller1.Screen.setCursor( 1, 1 );
    Controller1.Screen.print( Arm_Position) ;
    
    //Controller1.Screen.print("LT: %4.1f RT: %4.10f AT: %4.1f", LeftDriveSmart.temperature(fahrenheit), RightDriveSmart.temperature(fahrenheit), arm.temperature(fahrenheit));
    // wait(0.2, sec);
    Controller1.Screen.clearLine();
    
    Drivetrains.setStopping(coast);
    // int pos1 = inertial1.rotation();
    // int pos2 = inertial1.rotation();
    // int pos3 = inertial1.rotation();

    // int avPos = (pos1 + pos2 + pos3)/3;
    Brain.Screen.print("TL: %4.1f TR: %4.10f TM: %4.1f", trackingL.position(deg), trackingR.position(deg), trackingM.position(deg));
     wait(100, msec);


   }

}

void Intake_Override_senario () {
   intake.spin(fwd, 100, voltageUnits());
  wait(100,msec);
}
bool intakeoverride = false; 
void Skywalker () {


  bool Toggle_Variable = false ; 
  bool Off_Toggle_Variable = false ; 

  bool override_on = false ; 

 while (1==1 ){
   Brain.Screen.clearLine();

    Arm_Position = arm.position(rotationUnits::deg);
   
    ///
    if (Controller1.ButtonR1.pressing() and Controller1.ButtonR2.pressing() and Toggle_Variable == false and Off_Toggle_Variable == false   ){
     
      Toggle_Variable = true ; // set changes
      Arm_Set_Postion = Arm_Load_Position ;  //set likely changes
       override_on = false ; 
      Off_Toggle_Variable = false ;  // same
      Brain.Screen.print("one") ; 

     intakeoverride = false ; 
      

    }
    else if (!Controller1.ButtonR1.pressing() and !Controller1.ButtonR2.pressing() and Toggle_Variable == true and Off_Toggle_Variable == false ){
      override_on = false ; 
      Toggle_Variable = true ;  //same as before
      Arm_Set_Postion = Arm_Load_Position ;  //same as before 
      Off_Toggle_Variable = true ;   //set,  only thing that changes, 
       Brain.Screen.print("two") ; 
        intakeoverride = false ; 
    }
    else if (Controller1.ButtonR1.pressing() and Controller1.ButtonR2.pressing() and Toggle_Variable == true and  Off_Toggle_Variable == true ){
      override_on = false ; 
      thread(Intake_Override_senario).detach();
      wait(60,msec);
      Toggle_Variable = false ;  //changes
      Arm_Set_Postion = Arm_Score_Position ;  //set 
      Off_Toggle_Variable = true ;   //same as before
       Brain.Screen.print("three") ; 
        intakeoverride = true ; 
      

    }
    else if (!Controller1.ButtonR1.pressing() and !Controller1.ButtonR2.pressing() and Toggle_Variable == false and Off_Toggle_Variable == true) {
      override_on = false ; 

      
      Arm_Set_Postion = Arm_Score_Position ;  //same as before 
      Off_Toggle_Variable = false ;   //changes
       Brain.Screen.print("four") ; 
       intakeoverride = false ; 
      Toggle_Variable = false ;  
       Off_Toggle_Variable = false ;
    }


   
    else if (Controller1.ButtonR1.pressing()  and !Controller1.ButtonR2.pressing()) {
      override_on = true ; 
         Brain.Screen.print("five") ; 
        
        arm.spin(reverse, 100, voltageUnits());
      intakeoverride = false ; 
       Toggle_Variable = false ;  
       Off_Toggle_Variable = false ;

    }

    else if (!Controller1.ButtonR1.pressing()  and Controller1.ButtonR2.pressing()) {
      override_on = true ;   
         Brain.Screen.print("six") ; 
       arm.spin(fwd, 100, voltageUnits());


       Toggle_Variable = false ;  
       Off_Toggle_Variable = false ;
       intakeoverride = false ; 
    }

    else if (!Controller1.ButtonR1.pressing()  and !Controller1.ButtonR2.pressing() and override_on == true   ) {
       arm.stop(hold) ;
        Brain.Screen.print("seven") ; 
         intakeoverride = false ; 
    }

    
    if (override_on == false) {

    

      if (Arm_Position < Arm_Set_Postion - Arm_gap_precision ) {
         arm.spin(fwd, 100, voltageUnits());
          Brain.Screen.print(" !1") ; 
           


      }
      else if (Arm_Position > Arm_Set_Postion + Arm_gap_precision ) {
        arm.spin(reverse, 100, voltageUnits());
         Brain.Screen.print(" !2") ; 

        
      }
      else {
        arm.stop(hold) ;
         Brain.Screen.print(" !3") ; 
           
      }

    }

    
 



   wait(10,msec);

 }
  
}


  










void usercontrol() {
 // armDeg.resetPosition();
  // armDeg.setPosition(5, deg);
  // armDeg.setReversed(true);
  // User control code here, inside the loop
  // Brain.Screen.print( "  x: %4.0f   y: %4.0f   z: %4.0f", , launch.position( rev ) );
  RightDriveSmart.setStopping(coast);
  LeftDriveSmart.setStopping(coast);
  Drivetrains.setStopping(coast);
  //arm.setStopping(coast);
  intake.setStopping(coast);
  //arm.setVelocity(11, velocityUnits(volt));
  
  thread(Controller_Screen_Print).detach(); 
  thread(Skywalker).detach();
  

//Controller_Screen_Print() ;
  // process the controller input every 20 milliseconds
  // update the motors based on the input values
  while(true) {
    // inertialMain.installed();
    // Drivetrains.setTurnVelocity(40, percent);
    

    // flywheel.setVelocity(83, percent);
    
    if(RemoteControlCodeEnabled) {
      // calculate the drivetrain motor velocities from the controller joystick axies
      // left = Axis3 + Axis1
      // right = Axis3 - Axis18.
      double drivetrainLeftSideSpeed = ((Controller1.Axis3.position() + Controller1.Axis1.position()) /8 ) ;
      double drivetrainRightSideSpeed = ((Controller1.Axis3.position() - Controller1.Axis1.position()) /8 ) ;
    /*
      // //Forward speed with current joystick scaling
      // double Drivespd = Axis3 * (pow(M_E, -d / 10) + pow(M_E, (std::fabs(AxisB) - 100) / 10) * (1 - pow(M_E, -d / 10)));
      // //turn speed (from other joystick) with joystick scaling
      // double Turn = Axis1 * (pow(M_E, (fabs(Axis1) - 100) * t / 1000));

      // leftMotorFront.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorFront.spin(forward, (Drivespd + Turn)*1.27, pct);
      // leftMotorMiddle.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorMiddle.spin(forward, (Drivespd + Turn)*1.27, pct);
      // leftMotorBack.spin(reverse, (Drivespd - Turn)*1.27, pct);
      // rightMotorBack.spin(forward, (Drivespd + Turn)*1.27, pct);
    */
      // check if the value is inside of the deadband range
      if (drivetrainLeftSideSpeed < 1 && drivetrainLeftSideSpeed > -1) {
        // check if the left motor has already been stopped
        if (DrivetrainLNeedsToBeStopped_Controller1) {
          // stop the left drive motor
          LeftDriveSmart.stop();
          // tell the code that the left motor has been stopped
          DrivetrainLNeedsToBeStopped_Controller1 = false;
        }
      } else {
        // reset the toggle so that the deadband code knows to stop the left motor nexttime the input is in the deadband range
        DrivetrainLNeedsToBeStopped_Controller1 = true;
      }
      // check if the value is inside of the deadband range
      if (drivetrainRightSideSpeed < 1 && drivetrainRightSideSpeed > -1) {
        // check if the right motor has already been stopped
        if (DrivetrainRNeedsToBeStopped_Controller1) {
          // stop the right drive motor
          RightDriveSmart.stop();
          // tell the code that the right motor has been stopped
          DrivetrainRNeedsToBeStopped_Controller1 = false;
        }
      } else {
        // reset the toggle so that the deadband code knows to stop the right motor next time the input is in the deadband range
        DrivetrainRNeedsToBeStopped_Controller1 = true;
      }
      
      // only tell the left drive motor to spin if the values are not in the deadband range
      if (DrivetrainLNeedsToBeStopped_Controller1) {
        // LeftDriveSmart.setVelocity(drivetrainLeftSideSpeed, velocityUnits(volt));
        LeftDriveSmart.spin(forward, drivetrainLeftSideSpeed, voltageUnits(volt));

        // LeftDriveSmart.spin( vex::directionType::rev, 12, vex::voltageUnits::volt);
      }
      // only tell the right drive motor to spin if the values are not in the deadband range
      if (DrivetrainRNeedsToBeStopped_Controller1) {
        // RightDriveSmart.setVelocity(drivetrainRightSideSpeed, velocityUnits(volt));
        RightDriveSmart.spin(forward, drivetrainRightSideSpeed, voltageUnits(volt));
      }
      
      // check the ButtonR1/ButtonR2 status to control Intake
      if(Controller1.ButtonL1.pressing()){
        intake.spin(reverse, 100, voltageUnits(volt));
         intakeoverride = false ; 
      } else if(Controller1.ButtonL2.pressing()){
        intake.spin(forward, 100, voltageUnits(volt));
         intakeoverride = false ; 
      } else if ( intakeoverride == false ) {
        intake.stop();
      }

      Controller1.ButtonX.pressed(ClampDown  );
      Controller1.ButtonA.pressed(ClampUp);
      Controller1.ButtonLeft.pressed(DoinkerDown);
      Controller1.ButtonRight.pressed(DoinkerUp);
      
      // Controller1.ButtonLeft.pressed(wingLIn) and ButtonDown).pressed(wingLIn)
      // if(Controller1.ButtonLeft.pressing() and Controller1.ButtonRight.pressing() and Controller1.ButtonDown.pressing()){
      //   and_we_and_lift_off.set(true);
      // } else if(Controller1.ButtonUp.pressing()){
      //   and_we_and_lift_off.set(false);
      // }

      // Controller1.ButtonA.pressed(high_goal);
      // if(Controller1.ButtonA.pressing()){
      //   arm.spin(forward);
      // } else if( Controller1.ButtonB.pressing()){
      //   arm.spin(reverse);
      // } else{
      //   arm.stop(hold);
      // }
      
    
       


      

      // wait before repeating the process
      wait(10,msec);
      }
        
    }    
    
  }
  // return 1;




//
// Main will set up the competition functions and callbacks.
//
int main() {
  
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
 // Competition.drivercontrol(usercontrol);
  // Competition.drivercontrol(prints);
  // Run the pre-autonomous function.


 pre_auton();


  // register events for button selection
  Brain.Screen.pressed( userTouchCallbackPressed );
  Brain.Screen.released( userTouchCallbackReleased );

  // make nice background
  Brain.Screen.setFillColor( vex::color(0x000000) ); 
  Brain.Screen.setPenColor ( vex::color(0x000000) ); 
  Brain.Screen.drawRectangle( 0, 0, 480, 120 );

  // initial display
  displayButtonControls( 0, false );

  while(1) {
    Brain.Screen.setFont(fontType::mono20);
    Brain.Screen.setFillColor( vex::color(0x000000) );
    Brain.Screen.setPenColor ( vex::color(0x000000) ); 

    Brain.Screen.setFont(fontType::mono40);
    Brain.Screen.setFillColor( vex::color(0xFFB6C1) );

    Brain.Screen.setPenColor( vex::color(0x000000));
    Brain.Screen.printAt( 0, 135, " Captcha 621A      0.2.0 " );

    this_thread::sleep_for(30);
    Brain.Screen.setPenColor ( vex::color(0x000000) ); 
    wait(20, msec);
  }



  // // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
    
  }
}